function reverse(nu) {
    var revno = [];
    for (var i = nu.length - 1; i >= 0; i--) {
        revno.push(nu[i]);
    }
    return revno;
}
var sample = [1, 2, 3, 4, 5,];
var revnum = reverse(sample);
console.log(revnum);
var names = ['jay', 'ria'];
var revnames = reverse(names);
console.log(revnames);
