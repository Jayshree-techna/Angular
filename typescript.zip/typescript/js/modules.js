"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
var class_1 = require("../class");
var obj1 = new class_1.User('Jay', 'ba', '2734384');
obj1.display();
(0, class_1.show)();
