var square = function (p) {
    console.log(p * p);
    return p * p;
};
square(2);
console.log(square);
