var num = [1, 2, 3, 4, 5, 5, 7];
for (var j in num) {
    console.log(j + " " + num[j]);
}
for (var _i = 0, num_1 = num; _i < num_1.length; _i++) {
    var n = num_1[_i];
    console.log(n);
}
