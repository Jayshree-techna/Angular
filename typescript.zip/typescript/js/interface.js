function display(person) {
    console.log(person.name + " " + person.phone);
}
var p = { name: "Jayshree", phone: "578906" };
display(p);
display({ name: "Ria" });
