var cname = 'Jayshree';
var sentence = "hello ".concat(cname, "\n\n how are you?");
console.log(sentence);
