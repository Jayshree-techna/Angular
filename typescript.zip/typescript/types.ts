let no:number=2;
let welcome:String ="hello";
let char:boolean=true;
console.log(no);
console.log(welcome);
console.log(char);
 
let arr:number[]=[1,2,2,];
for(var i=0;i<arr.length;i++)
console.log(arr[i]);

let n:any=19;
n="Hello";