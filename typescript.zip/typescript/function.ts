//optional arguement
// function add(num:number,num2 :number,n3?:number):void{
// if(n3===undefined){
//     console.log(num+num2);
// }
// console.log(num+num2+n3);

// }

// add(2,3,8);
// add(1,3);

//default arguement

// function message(food:string,drinks:string="mazza"):void{
//     console.log(`Have the food ${food} along with ${drinks}`);
// }

// message('Veg');message
// ('Veg','coke');

//rest parameters
function company(a,...b){
    console.log(a+" "+b.length);
}

company('jay');
company('ria','j','a','y','s')