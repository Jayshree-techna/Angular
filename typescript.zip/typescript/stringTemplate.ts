var cname='Jayshree';
var sentence=`hello\ ${cname}
\n how are you?`;

console.log(sentence);