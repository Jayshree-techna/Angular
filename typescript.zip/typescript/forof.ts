var num=[1,2,3,4,5,5,7]
for(var j in num){
    console.log(j+" "+num[j])
}

for(var n of num){
    console.log(n);
}