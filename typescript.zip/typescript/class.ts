    export class User{
    //     name:string;
    // city:string;
    // phone:number;

    // constructor(public name:string, public city:string,public phone:string){
    //     // this.name=name;
    //     // this.city=city;
    //     this.phone='+91-'+this.phone;
    //     }
  constructor(private name:string, private city:string,private phone:string){
    // this.name=name;
    // this.city=city;
    this.phone='+91-'+this.phone;
    }

    public get Name(){
    return this.name;
    }
    public get Phone(){
        return this.phone;
    }
    public get City(){
        return this.city;
    }
 
    public set Phone(ph:string){
        this.phone='+91-'+ph;
    }
    public set Name(name:string){
        this.name=name;
    }
    public set City(city:string){
         this.city=city;
     }

    public display(){
        console.log(this.name,this.city,this.phone);
         }

    }
    var user1=new User('j','ka','9392');
    // user1.name='jay';
    // user1.city='ka';
    // user1.phone=442422;

    console.log(user1.Name+" "+user1.Phone+" "+user1.City);
    user1.Phone='834303';
    console.log(user1.Name+" "+user1.Phone+" "+user1.City);
     
    export function show(){
        console.log("show called");
    }