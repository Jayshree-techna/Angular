var square=(p:number):number=>{
    console.log(p*p);
    return p*p;
}

square(2);
console.log(square)