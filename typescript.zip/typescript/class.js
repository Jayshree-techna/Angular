"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.show = exports.User = void 0;
var User = /** @class */ (function () {
    //     name:string;
    // city:string;
    // phone:number;
    // constructor(public name:string, public city:string,public phone:string){
    //     // this.name=name;
    //     // this.city=city;
    //     this.phone='+91-'+this.phone;
    //     }
    function User(name, city, phone) {
        this.name = name;
        this.city = city;
        this.phone = phone;
        // this.name=name;
        // this.city=city;
        this.phone = '+91-' + this.phone;
    }
    Object.defineProperty(User.prototype, "Name", {
        get: function () {
            return this.name;
        },
        set: function (name) {
            this.name = name;
        },
        enumerable: false,
        configurable: true
    });
    Object.defineProperty(User.prototype, "Phone", {
        get: function () {
            return this.phone;
        },
        set: function (ph) {
            this.phone = '+91-' + ph;
        },
        enumerable: false,
        configurable: true
    });
    Object.defineProperty(User.prototype, "City", {
        get: function () {
            return this.city;
        },
        set: function (city) {
            this.city = city;
        },
        enumerable: false,
        configurable: true
    });
    User.prototype.display = function () {
        console.log(this.name, this.city, this.phone);
    };
    return User;
}());
exports.User = User;
var user1 = new User('j', 'ka', '9392');
// user1.name='jay';
// user1.city='ka';
// user1.phone=442422;
console.log(user1.Name + " " + user1.Phone + " " + user1.City);
user1.Phone = '834303';
console.log(user1.Name + " " + user1.Phone + " " + user1.City);
function show() {
    console.log("show called");
}
exports.show = show;
