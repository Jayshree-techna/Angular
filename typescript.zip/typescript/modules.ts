import {User, show} from './class'
var obj1=new User('Jay','ba','2734384');
obj1.display();
show();