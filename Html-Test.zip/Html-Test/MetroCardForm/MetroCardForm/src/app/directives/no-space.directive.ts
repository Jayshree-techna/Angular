import { Directive, HostListener } from '@angular/core';

@Directive({
  selector: '[appNoSpace]'
})
export class NoSpaceDirective {

  @HostListener('input',['$event']) onInput(event:KeyboardEvent):void{
    const inputElement=event.target as HTMLInputElement;
    const cursorPosition = inputElement.selectionStart;
    const inputValue=inputElement.value.replace(/\s/g,'');
    inputElement.value=inputValue;
    inputElement.setSelectionRange(cursorPosition, cursorPosition);
  }

}
