import { NoSpaceDirective } from './no-space.directive';

describe('NoSpaceDirective', () => {
  it('should create an instance', () => {
    const directive = new NoSpaceDirective();
    expect(directive).toBeTruthy();
  });
});
