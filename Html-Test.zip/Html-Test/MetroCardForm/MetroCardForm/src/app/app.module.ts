import { MatTooltipModule } from '@angular/material/tooltip';
import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { HttpClientModule } from '@angular/common/http';
import { LicenseRenewalComponent } from './Components/LicenseRenewalForm/license-renewal/license-renewal.component';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { HeaderComponent } from './Components/Common/header/header.component';
import { FooterComponent } from './Components/Common/footer/footer.component';
import { CustomerLoginComponent } from './Components/CustomerLogin/customer-login/customer-login.component';
import { ReferFriendComponent } from './Components/CustomerLogin/refer-friend/refer-friend.component';
import { AdminLoginComponent } from './Components/AdminLogin/admin-login/admin-login.component';
import { EmailUpdateListingComponent } from './Components/AdminLogin/email-update-listing/email-update-listing.component';
import { CustomerUploadComponent } from './Components/customer-upload/customer-upload.component';
import { AdminDashboardComponent } from './Components/AdminLogin/admin-dashboard/admin-dashboard.component';
import { CustomerDashboardComponent } from './Components/CustomerLogin/customer-dashboard/customer-dashboard.component';
import { InnerHeaderComponent } from './Components/Common/inner-header/inner-header.component';
import { InnerFooterComponent } from './Components/Common/inner-footer/inner-footer.component';
import { TableComponent } from './Components/Common/table/table.component';
import { ThankYouComponent } from './Components/thank-you/thank-you.component';
import { ErrorComponent } from './Components/error/error.component';
import { TermsAndConditionComponent } from './Components/terms-and-condition/terms-and-condition.component';
import { LicenseRenewalListComponent } from './Components/AdminLogin/license-renewal-list/license-renewal-list.component';
import { ReferralService } from './services/referral.service';
import { AddonListingComponent } from './Components/CustomerLogin/addon-listing/addon-listing.component';
import { AdminReferralListComponent } from './Components/AdminLogin/admin-referral-list/admin-referral-list.component';
import { AddOnListingComponent } from './Components/AdminLogin/add-on-listing/add-on-listing.component';

import { ToastrModule } from 'ngx-toastr';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { NgxPaginationModule } from 'ngx-pagination';
import { NgbModule } from '@ng-bootstrap/ng-bootstrap';
import { LoaderComponent } from './Components/Common/loader/loader.component';
import { AddonconsentComponent } from './Components/CustomerLogin/addonconsent/addonconsent.component';
import { NumericOnlyDirective } from './directives/numeric-only.directive';
import { NoSpaceDirective } from './directives/no-space.directive';
import { JwtHelperService, JwtModule } from '@auth0/angular-jwt';



@NgModule({
  declarations: [
    AppComponent,
    HeaderComponent,
    FooterComponent,
    LicenseRenewalComponent,
    LicenseRenewalListComponent,
    CustomerLoginComponent,
    AddonListingComponent,
    AddOnListingComponent,
    ReferFriendComponent,
    EmailUpdateListingComponent,
    CustomerUploadComponent,
    AdminDashboardComponent,
    AdminReferralListComponent,
    CustomerDashboardComponent,
    InnerHeaderComponent,
    InnerFooterComponent,
    TableComponent,
    ThankYouComponent,
    ErrorComponent,
    TermsAndConditionComponent,
    AdminLoginComponent,
    LoaderComponent,
    AddonconsentComponent,
    NumericOnlyDirective,
    NoSpaceDirective,


  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    FormsModule,
    HttpClientModule,
    ReactiveFormsModule,
    ToastrModule.forRoot({
      timeOut: 2000,
      progressBar: true,
      progressAnimation: 'increasing',
      countDuplicates: false,
    }),
    BrowserAnimationsModule,
    NgxPaginationModule,
    NgbModule,
    MatTooltipModule,
    JwtModule.forRoot({
      config: {
        tokenGetter: () => {
          return sessionStorage.getItem('token');
        },
      },
    }),

  ],
  providers: [
    ReferralService,
    JwtHelperService,
  ],
  bootstrap: [AppComponent],
})
export class AppModule {}
