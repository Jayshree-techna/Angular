import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { AddOnListingComponent } from './Components/AdminLogin/add-on-listing/add-on-listing.component';
import { AdminDashboardComponent } from './Components/AdminLogin/admin-dashboard/admin-dashboard.component';
import { AdminLoginComponent } from './Components/AdminLogin/admin-login/admin-login.component';
import { AdminReferralListComponent } from './Components/AdminLogin/admin-referral-list/admin-referral-list.component';
import { EmailUpdateListingComponent } from './Components/AdminLogin/email-update-listing/email-update-listing.component';
import { LicenseRenewalListComponent } from './Components/AdminLogin/license-renewal-list/license-renewal-list.component';
import { AddonListingComponent } from './Components/CustomerLogin/addon-listing/addon-listing.component';
import { CustomerDashboardComponent } from './Components/CustomerLogin/customer-dashboard/customer-dashboard.component';
import { CustomerLoginComponent } from './Components/CustomerLogin/customer-login/customer-login.component';
import { ReferFriendComponent } from './Components/CustomerLogin/refer-friend/refer-friend.component';
import { LicenseRenewalComponent } from './Components/LicenseRenewalForm/license-renewal/license-renewal.component';
import { CustomerUploadComponent } from './Components/customer-upload/customer-upload.component';
import { ErrorComponent } from './Components/error/error.component';
import { TermsAndConditionComponent } from './Components/terms-and-condition/terms-and-condition.component';
import { ThankYouComponent } from './Components/thank-you/thank-you.component';
import { authGuard, authGuardForCustomer } from './services/auth-guard.service';
import { AddonconsentComponent } from './Components/CustomerLogin/addonconsent/addonconsent.component';

const routes: Routes = [
  {
    path: 'licenseRenewalForm',
    component: LicenseRenewalComponent
  },
  {
    path: 'customerLogin',
    component: CustomerLoginComponent,
  },
  {
    path: 'referFriend',
    component: ReferFriendComponent,
    canActivate :[authGuardForCustomer]
  },
  {
    path: 'customerDashboard',
    component: CustomerDashboardComponent,
    canActivate :[authGuardForCustomer]

  },
  {
    path: 'login',
    component: AdminLoginComponent,
  },
  {
    path: 'customerUpload',
    component: CustomerUploadComponent,
    canActivate :[authGuard]

  },
  {
    path: 'emailList',
    component: EmailUpdateListingComponent,
    canActivate: [authGuard]
  },
  {
    path: 'licenseList',
    component: LicenseRenewalListComponent,
    canActivate: [authGuard]
  },
  {
    path: 'dashboard',
    component: AdminDashboardComponent,
    canActivate: [authGuard]
  },
  {
    path: 'referralList',
    component: AdminReferralListComponent,
    canActivate: [authGuard]
  },
  {
    path: 'addonList',
    component: AddOnListingComponent,
    canActivate: [authGuard]
  },

  {
    path: 'addOnForm',
    component: AddonListingComponent,
    canActivate :[authGuardForCustomer]
  },
  {
    component: CustomerLoginComponent,
    pathMatch: 'full',
    path: '',
  },
  {
    component: AddonconsentComponent,
    path: 'consent/:id',
    // path:'consent'
  },
  {
    component: ThankYouComponent,
    path: 'thankYou',
  },
  {
    component: ErrorComponent,
    path: 'error',
  },
  {
    component: TermsAndConditionComponent,
    path: 'termsAndCondition',
  },
  {
    path: '**',
    // component: ErrorComponent,
    redirectTo:'error'
  },
];
@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule],
})
export class AppRoutingModule { }
