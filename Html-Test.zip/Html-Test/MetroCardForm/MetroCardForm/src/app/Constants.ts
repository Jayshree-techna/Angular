
 const ApiEndpoint = 'http://localhost:8080';
// const ApiEndpoint='http://fma-demo.centralindia.cloudapp.azure.com:8020/metroforms';

export const AppSettings = {

  Urls: {
    Login: {
      getCustomerLogin: ApiEndpoint + '/auth/customerLogin',
    },
    CustomerUpload: {
      uploadExcel: ApiEndpoint + "/customerUploadExcel",
      clear: ApiEndpoint + "/customerUploadClearData",
      validate: ApiEndpoint + "/customerUploadValidateData",
      process: ApiEndpoint + "/customerUploadProcessData",
      customerHistory:ApiEndpoint+"/getCustomerUploadHistory"
    },
    Email: {
      emailUpdate: ApiEndpoint + '/api/customer/emailUpdate',
    },
    Customer: {
      dashboardData: ApiEndpoint + '/license/getCustomerLicenseDetails',
      referrals: ApiEndpoint + '/referral/saveReferral',
      addon:ApiEndpoint+'/listing/createAddOnCard',
      user:ApiEndpoint+'/auth/getUserDetails',
      position:ApiEndpoint+'/dataFetch/getPosition',
      getConsent:ApiEndpoint+'/api/customer/getConsent',
      submitConsent:ApiEndpoint+'/api/customer/submitConsent'
    },
    Admin:{
      login:ApiEndpoint+'/auth/login',
      getReferralList: ApiEndpoint+'/referral/getReferralList',
      getEmailList:ApiEndpoint+'/api/customer/getUpdatedEmailList',
      getAddonList:ApiEndpoint+'/listing/AddOnCardDetails',
      getLicenseList:ApiEndpoint+'/license/getLicenseList',
      licenseDownload:ApiEndpoint+'/licenseDownload',
      referralDownload:ApiEndpoint+'/referralDownload',
      emailDownload:ApiEndpoint+'/emailDownload',
      addonDownload:ApiEndpoint+'/addonDownload',
      downloadPhoto:ApiEndpoint+'/downloadPhoto',
      downloadLicensePhoto:ApiEndpoint+'/downloadLicenseFile'
    },
    LicenseForm:{
      submitLicenseForm:ApiEndpoint+'/license/saveLicenseRenewal',
      licenseDropDownList:ApiEndpoint+'/dataFetch/licenserenewal'
    },
    Generate:{
      emailOtp:ApiEndpoint+'/generateEmailOtp',
      mainOtp:ApiEndpoint+'/generateMainOtp',
    },
    Validate:{
      otp:ApiEndpoint+'/validateOtp',
    },

  }
};
