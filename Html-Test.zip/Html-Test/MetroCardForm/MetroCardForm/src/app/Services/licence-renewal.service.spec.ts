import { TestBed } from '@angular/core/testing';

import { LicenceRenewalService } from './licence-renewal.service';

describe('LicenceRenewalService', () => {
  let service: LicenceRenewalService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(LicenceRenewalService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
