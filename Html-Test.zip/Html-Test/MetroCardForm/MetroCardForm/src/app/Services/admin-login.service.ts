import {
  HttpClient,
  HttpHeaders,
  HttpParams,
  HttpResponse,
} from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Router } from '@angular/router';
import { Observable, map } from 'rxjs';
import { AppSettings } from '../Constants';

@Injectable({
  providedIn: 'root',
})
export class AdminLoginService {
  public paramObject = {};

  public httpOptionsDownload:
    | {
        headers: HttpHeaders;
        responseType?: 'json';
        observe?: 'body';
      }
    | undefined;

  constructor(private http: HttpClient, private router: Router) {}

  downloadLicense(idGroup: number[], dateRange: HttpParams) {
    console.log('inside download');
    const header = {
      Authorization: 'Bearer ' + this.getToken(),
    };
    const reqOptions = {
      headers: new HttpHeaders(header),
      params: dateRange,
      responseType: 'blob' as 'json',
    };

    console.log(
      'ids----> ',
      idGroup,
      'date---->',
      dateRange,
      'reqop--->',
      reqOptions
    );
    return this.http.post(
      AppSettings.Urls.Admin.licenseDownload,
      idGroup,
      reqOptions
    );
  }

  downloadEmail(ids: number[], selectedDate?: HttpParams) {
    const header = {
      Authorization: 'Bearer ' + this.getToken(),
    };
    const reqOptions = {
      headers: new HttpHeaders(header),
      params: selectedDate,
      responseType: 'blob' as 'json',
    };

    return this.http.post(
      AppSettings.Urls.Admin.emailDownload,
      ids,
      reqOptions
    );
  }

  downloadReferral(ids: number[], selectedDate: HttpParams) {
    const header = {
      Authorization: 'Bearer ' + this.getToken(),
    };
    const reqOptions = {
      headers: new HttpHeaders(header),
      params: selectedDate,
      responseType: 'blob' as 'json',
    };
    return this.http.post(
      AppSettings.Urls.Admin.referralDownload,
      ids,
      reqOptions
    );
  }
  downloadAddon(ids: number[], selectedDate?: HttpParams) {
    const header = {
      Authorization: 'Bearer ' + this.getToken(),
    };
    const reqOptions = {
      headers: new HttpHeaders(header),
      params: selectedDate,
      responseType: 'blob' as 'json',
    };

    return this.http.post(
      AppSettings.Urls.Admin.addonDownload,
      ids,
      reqOptions
    );
  }

  doLogin(contactForm: any) {
    console.log('admin login' + AppSettings.Urls.Admin.login);
    return this.http.post(AppSettings.Urls.Admin.login, contactForm);
  }

  loginUser(token: string) {
    sessionStorage.removeItem('token');
    sessionStorage.setItem('token', token);
    return true;
  }
  setRole(role: boolean) {
    sessionStorage.removeItem('role');

    if (role) {
      sessionStorage.setItem('role', 'true');
    } else sessionStorage.setItem('role', 'false');
  }
  getRole() {
    return sessionStorage.getItem('role');
  }
  isLoggedIn() {
    let token = sessionStorage.getItem('token');
    if (token == null || token == '' || token == undefined) {
      return false;
    } else {
      return true;
    }
  }

  logout() {
    sessionStorage.removeItem('token');
    sessionStorage.removeItem('role');
    this.router.navigate(['login']);
    return true;
  }
  getToken() {
    return sessionStorage.getItem('token');
  }

  // getUserDetails(){
  //   const headers = new HttpHeaders().set('Authorization','Bearer '+this.getToken)
  //   // 'Authorization': `Bearer ${this.getToken}`});
  //   // const token = this.getToken(); // Assuming getToken is a method that retrieves the token
  //   // const urlWithToken = `${this.url1}?token=${token}`;
  //   return this.http.get(`${this.url1}`,{ headers:headers });
  //   // return this.http.get(urlWithToken);
  // }
  getUserDetails() {
    const headers = new HttpHeaders().set(
      'Authorization',
      'Bearer ' + this.getToken()
    );
    return this.http.get(`${AppSettings.Urls.Customer.user}`, {
      headers: headers,
    });
  }
  getPosition() {
    // const headers = new HttpHeaders().set('Authorization', 'Bearer ' + this.otpService.GetHeaderOptions());
    return this.http.get(`${AppSettings.Urls.Customer.position}`);
  }

  downloadPhoto(filename: string): Observable<Blob> {
    let headers = new HttpHeaders().set(
      'Authorization',
      'Bearer ' + sessionStorage.getItem('token')
    );
    let params = new HttpParams().set('filename', filename);
    return this.http
      .post(AppSettings.Urls.Admin.downloadPhoto, params, {
        headers: headers,
        observe: 'response',
        responseType: 'blob',
      })
      .pipe(
        map((response: HttpResponse<Blob>) => {
          return response.body || new Blob();
        })
      );
  }

  downloadLicensePhoto(filename: string): Observable<Blob> {
    let headers = new HttpHeaders().set(
      'Authorization',
      'Bearer ' + sessionStorage.getItem('token')
    );
    let params = new HttpParams().set('id', filename);
    return this.http
      .post(AppSettings.Urls.Admin.downloadLicensePhoto, params, {
        headers: headers,
        observe: 'response',
        responseType: 'blob',
      })
      .pipe(
        map((response: HttpResponse<Blob>) => {
          return response.body || new Blob();
        })
      );
  }
}


