import { HttpClient, HttpHeaders, HttpParams } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { AppSettings } from '../Constants';

@Injectable({
  providedIn: 'root',
})
export class OtpService {
  mobileNumber!: string;
  constructor(private http: HttpClient) { }

  generateEmailOtp(cardNumber: number, custEmail: string): Observable<any> {
    let params = new HttpParams()
      .append('customerId', cardNumber)
      .append('custEmail', custEmail);
    return this.http.post(AppSettings.Urls.Generate.emailOtp, params);
  }

  generateMainOtp(customerId: number, custMobile: string): Observable<any> {
    // let customerId=localStorage.getItem("id");
    // if(customerId != null){
    let params = new HttpParams()
      .append('customerId', customerId)
      .append('custMobile', custMobile);
    return this.http.post(AppSettings.Urls.Generate.mainOtp, params);
  }

  public GetHeaderOptions() {
    console.log(sessionStorage.getItem('token'));
    return new HttpHeaders({
      'Content-Type': 'application/json',
      'Authorization': 'Bearer ' + sessionStorage.getItem('token'),
    });
  }

  public GetMultipartHeaderOptions() {
    return new HttpHeaders({
      // 'Content-Type': 'multipart/form-data',
      // 'reportProgress': 'true',
      'Authorization': 'Bearer ' + sessionStorage.getItem('token'),
    });
  }

  validateMailOtp(customerId: number, otp: string) {
    let params = new HttpParams()
      .set('customerId', customerId)
      .set('otp', otp)
      .set('otpType', 'newemail_otp');
    return this.http.post(AppSettings.Urls.Validate.otp, params);
  }
  validateMainMailOtp(customerId: number, otp: string) {
    let params = new HttpParams()
      .append('customerId', customerId)
      .append('otp', otp)
      .append('otpType', 'form_otp');
    return this.http.post(AppSettings.Urls.Validate.otp, params);
  }
}
