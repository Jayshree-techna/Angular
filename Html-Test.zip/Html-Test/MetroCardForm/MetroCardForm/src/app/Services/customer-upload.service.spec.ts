import { TestBed } from '@angular/core/testing';

import { CustomerUploadService } from './customer-upload.service';

describe('CustomerUploadService', () => {
  let service: CustomerUploadService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(CustomerUploadService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});


