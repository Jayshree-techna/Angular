import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders, HttpParams } from '@angular/common/http';
import { AdminLoginService } from './admin-login.service';
import { AppSettings } from '../Constants';

@Injectable({
  providedIn: 'root',
})
export class ReferralService {
  constructor(private http: HttpClient, private service: AdminLoginService) {}

  getRefferelList(fromDate?: string, toDate?: string) {
    console.log('in referral service------>' + 'from- ' + fromDate + 'to- ' + toDate);
    const headers = new HttpHeaders().set(
      'Authorization',
      'Bearer ' + this.service.getToken()
    );

    const params = new HttpParams()
      .append('fromDate', fromDate || '')
      .append('toDate', toDate || '');
      const urlWithParams = `${AppSettings.Urls.Admin.getReferralList}?${params.toString()}`;
      return this.http.get(urlWithParams, { headers:headers });

  }
}
