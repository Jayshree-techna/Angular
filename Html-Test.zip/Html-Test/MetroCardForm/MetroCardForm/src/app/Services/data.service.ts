import { Injectable } from '@angular/core';
import { EmailUpdate } from '../model/EmailUpdate';
import { BehaviorSubject } from 'rxjs';

@Injectable({
  providedIn: 'root',
})
export class DataService {
  private email = new BehaviorSubject<EmailUpdate>(new EmailUpdate());
  email$ = this.email.asObservable();

  constructor() {}

  setEmailValue(value: EmailUpdate): void {
    this.email.next(value);
  }

  getEmailValue(): EmailUpdate {
    return this.email.getValue();
  }
}
