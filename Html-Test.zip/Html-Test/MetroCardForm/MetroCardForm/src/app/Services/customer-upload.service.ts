import { HttpClient, HttpHeaders, HttpParams } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { AppSettings } from '../Constants';
import { EmailUpdate } from '../model/EmailUpdate';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class CustomerUploadService {
  constructor(private http: HttpClient) { }

  saveReferrals(customerReferral: any) {
    return this.http.post(AppSettings.Urls.Customer.referrals, customerReferral, { headers: this.GetHeaderOptions(), observe: 'response' });
  }

  uploadFile(file: FormData) {
    // let params = new HttpParams().append('file', file)
    return this.http.post(AppSettings.Urls.CustomerUpload.uploadExcel, file, { headers: this.GetHeaderOptionsForFile(), observe: 'response' });

  }

  submitConsent(consentId: string): Observable<any> {
    console.log("Consent submit")
    const url = `${AppSettings.Urls.Customer.submitConsent}?consentId=${consentId}`;
    return this.http.post(url, null);
  }

  getConsent(consentId: string): Observable<any> {
    const url = `${AppSettings.Urls.Customer.getConsent}?consentId=${consentId}`;
    return this.http.get(url);
  }

  clearApi() {
    return this.http.delete(AppSettings.Urls.CustomerUpload.clear, {
      headers: this.GetHeaderOptions(),
      observe: 'response'
    });
  }

  validate() {
    return this.http.get(AppSettings.Urls.CustomerUpload.validate, {
      headers: this.GetHeaderOptions(),
      observe: 'response'
    })
  }

  process() {
    return this.http.post(AppSettings.Urls.CustomerUpload.process, {}, {
      headers: this.GetHeaderOptions(),
      observe: 'response'
    })
  }

  emailUpdate(email: EmailUpdate) {
    return this.http.post(AppSettings.Urls.Email.emailUpdate, email, {
      headers: this.GetHeaderOptions(),
      observe: 'response',
    });
  }

  getCustomerDashboardData(customerId: any): Observable<any> {
    const url = `${AppSettings.Urls.Customer.dashboardData}?customerId=${customerId}`;
    return this.http.get(url, {
      headers: { 'Content-Type': 'application/json' },
      observe: 'response',
    });
  }

  public customerHistory(){
    return this.http.get(AppSettings.Urls.CustomerUpload.customerHistory,{
      headers: this.GetHeaderOptions(),
      observe: 'response'
    })
  }

  public GetHeaderOptions() {
    console.log(sessionStorage.getItem('token'));
    return new HttpHeaders({
      'Content-Type': 'application/json',
      'Authorization': 'Bearer ' + sessionStorage.getItem('token')
    });
  }

  public GetHeaderOptionsForFile() {
    return new HttpHeaders({
      // 'Content-Type': 'multipart/form-data',
      'Authorization': 'Bearer ' + sessionStorage.getItem('token')
    });
  }
}
