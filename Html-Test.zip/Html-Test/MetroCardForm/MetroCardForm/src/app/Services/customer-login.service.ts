import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { AppSettings } from '../Constants';

export class CustomerLogin {
  public mobileNumber?: string = '';
  public cardNumber?: string = '';
  public cardHolderNumber: string = '';
}

@Injectable({
  providedIn: 'root',
})
export class CustomerLoginService {
  constructor(private http: HttpClient) {}

  customerLogin(cusotmer: any) {
    return this.http.post(AppSettings.Urls.Login.getCustomerLogin, cusotmer, {
      headers: { 'Content-Type': 'application/json' },
      observe: 'response',
    });
  }
}
