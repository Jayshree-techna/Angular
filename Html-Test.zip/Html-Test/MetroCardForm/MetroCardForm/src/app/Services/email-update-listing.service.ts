import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders, HttpParams } from '@angular/common/http';
import { AdminLoginService } from './admin-login.service';
import { AppSettings } from '../Constants';

@Injectable({
  providedIn: 'root',
})
export class EmailUpdateListingService {


  constructor(private http: HttpClient, private service: AdminLoginService) {}

  getEmailList(fromdate?: string, todate?: string) {
    console.log(
      'in email service------>' + 'from- ' + fromdate + 'to- ' + todate
    );
    const headers = new HttpHeaders().set(
      'Authorization',
      'Bearer ' + this.service.getToken()
    );

    const params = new HttpParams()
      .append('fromDate', fromdate || '')
      .append('toDate', todate || '');

    const urlWithParams = `${AppSettings.Urls.Admin.getEmailList}?${params.toString()}`;
    return this.http.get(urlWithParams, { headers: headers });
  }

  getAddOnList(fromdate?: string, todate?: string) {
    console.log(
      'in addon service------>' + 'from- ' + fromdate + 'to- ' + todate
    );
    const headers = new HttpHeaders().set(
      'Authorization',
      'Bearer ' + this.service.getToken()
    );

    const queryParams = new HttpParams()
      .append('fromDate', fromdate || '')
      .append('toDate', todate || '');

    console.log('query params  ----->' + queryParams);

    const urlWithParams = `${AppSettings.Urls.Admin.getAddonList}?${queryParams.toString()}`;
    return this.http.get(urlWithParams, { headers: headers });
  }
}
