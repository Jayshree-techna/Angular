import { HttpClient, HttpHeaders, HttpParams } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { AddonSubmit } from '../model/AddonForm';
import { OtpService } from './otp.service';
import { AppSettings } from '../Constants';

@Injectable({
  providedIn: 'root'
})
export class AddonCardFormService {


  constructor(private http: HttpClient, private otpService: OtpService) { }

  // addAddonDetailsList(dto: any, file1:any) {
  addAddonDetailsList(dto: FormData) {
    // let params=new HttpParams().append('dto',dto);
    // const dto: FormData = new FormData();

    //   // Append addonDetailsList as a JSON string
    //   dto.append('dto', JSON.stringify(addonDetailsList));

    //  // Append files only if they are defined
    //  if (file1) dto.append('file1', file1);
    //  if (file2) dto.append('file2', file2);
    //  if (file3) dto.append('file3', file3);
    //  if (file4) dto.append('file4', file4);
    //  if (file1) dto.append('addonFile1', file1);
    //  if (file2) dto.append('addonFile2', file2);
    //  if (file3) dto.append('addonFile3', file3);
    //  if (file4) dto.append('addonFile4', file4);


    // dto ={
    //   dto
    // }
    // dto.forEach((value, key) => {
    //   console.log(`${key}: ${value}`);
    // });
    // let params=new HttpParams().set('dto',dto);
    return this.http.post(AppSettings.Urls.Customer.addon, dto, { headers: this.otpService.GetMultipartHeaderOptions() });
  }

}


