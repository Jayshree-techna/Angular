import { TestBed } from '@angular/core/testing';

import { AddonCardFormService } from './addon-card-form.service';

describe('AddonCardFormService', () => {
  let service: AddonCardFormService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(AddonCardFormService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
