import { TestBed } from '@angular/core/testing';

import { EmailUpdateListingService } from './email-update-listing.service';

describe('EmailUpdateListingService', () => {
  let service: EmailUpdateListingService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(EmailUpdateListingService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
