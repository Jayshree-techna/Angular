import { AppSettings } from '../Constants';
import { HttpClient, HttpParams, HttpHeaders } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { AdminLoginService } from './admin-login.service';

export interface LicenseCustomerData {
  mobile: string;
  cardNumber: string;
  companyName: string;
  id: number;
  licenseExpireOn: any;
}

export interface LicenseDto {
  customerId: number;
  cardNumber: string;
  applicantMobile: string;
  licenseTypeId: string;
  applicantWhatsapp: string;
  notUsingWhatsapp: boolean;
  applicantEmail: string;
  applicantNewMobile: string;
  businessClassificationId: string;
  businessSegment: string;
  otherBusinessClassification: string;
  currentBusinessAddress: string;
  socialMediaId: number;
  adMediaId: number;
  chatMediaId: number;
  modeCorrection: string;
  srid: string;
}

export interface LicenseList {
  id: number;
  licenseType: string;
}

export interface Businessclassification {
  id: number;
  businessSegment: string;
  businessClassification: string;
}

export interface CommunicationMedium {
  id: number;
  mediumType: string;
  mediumName: string;
}
@Injectable({
  providedIn: 'root',
})
export class LicenceRenewalService {
  constructor(private http: HttpClient, private admin: AdminLoginService) {}
  url: any;
  service: any;
  licenseToken: string = '';

  getCustomerData(
    mobileNo: string,
    cardNo: string
  ): Observable<LicenseCustomerData> {
    let params = new HttpParams()
      .set('mobileNo', mobileNo)
      .set('cardNo', cardNo);
    return this.http.get<LicenseCustomerData>(
      AppSettings.Urls.Customer.dashboardData,
      { params }
    );
  }

  saveLicenseFormToken(token: string) {
    this.licenseToken = token;
  }

  getLicenseList(fromDate?: string, toDate?: string){
    console.log('in service------>' + 'from- ' + fromDate + 'to- ' + toDate);

    const headers = new HttpHeaders().set(
      'Authorization',
      'Bearer ' + this.admin.getToken()
    );

    const queryParams = new HttpParams()
      .append('fromDate', fromDate || '')
      .append('toDate', toDate || '');

    const url = `${AppSettings.Urls.Admin.getLicenseList}?${queryParams.toString()}`;

    return this.http.get(url, { headers: headers });
  }

  getLicenseDropDownData(token: string) {
    const headers = new HttpHeaders().set('Authorization', 'Bearer ' + token);
    return this.http.get(AppSettings.Urls.LicenseForm.licenseDropDownList,{headers:headers});
  }

  submitLicenseForm(licenseDto: any,token:any) {
    const headers = new HttpHeaders().set('Authorization', 'Bearer ' + token);
    return this.http.post(
      AppSettings.Urls.LicenseForm.submitLicenseForm,
      licenseDto,{headers:headers}
    );
  }
}
