
import {CanActivateFn,Router} from '@angular/router';
import { AdminLoginService } from './admin-login.service';
import {inject} from '@angular/core';

export const authGuard: CanActivateFn = (route, state) => {
  const router=inject(Router);
  const service=inject(AdminLoginService);

  if(service.isLoggedIn()){
    return true;
  }
  else{
    router.navigateByUrl('/login');
    return false;
  }

};
export const authGuardForCustomer: CanActivateFn = (route, state) => {
  const router=inject(Router);
  const service=inject(AdminLoginService);

  if(service.isLoggedIn()){
    return true;
  }
  else{
    router.navigateByUrl('/customerLogin');
    return false;
  }

};
