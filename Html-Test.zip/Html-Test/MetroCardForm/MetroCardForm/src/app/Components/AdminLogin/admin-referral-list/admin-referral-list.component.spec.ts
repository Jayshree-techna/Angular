import { ComponentFixture, TestBed } from '@angular/core/testing';

import { AdminReferralListComponent } from './admin-referral-list.component';

describe('AdminReferralListComponent', () => {
  let component: AdminReferralListComponent;
  let fixture: ComponentFixture<AdminReferralListComponent>;

  beforeEach(() => {
    TestBed.configureTestingModule({
      declarations: [AdminReferralListComponent]
    });
    fixture = TestBed.createComponent(AdminReferralListComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
