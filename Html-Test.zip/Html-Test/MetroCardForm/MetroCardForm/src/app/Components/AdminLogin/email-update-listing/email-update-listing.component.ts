import { HttpParams } from '@angular/common/http';
import { Component, OnInit, inject } from '@angular/core';
import { Router } from '@angular/router';
import { NgbCalendar, NgbDate, NgbDateParserFormatter } from '@ng-bootstrap/ng-bootstrap';
import { ToastrService } from 'ngx-toastr';
import { AdminLoginService } from 'src/app/services/admin-login.service';
import { AuthServiceService } from 'src/app/services/auth-service.service';
import { EmailUpdateListingService } from 'src/app/services/email-update-listing.service';
import { SpinnerService } from 'src/app/services/spinner.service';

@Component({
  selector: 'app-email-update-listing',
  templateUrl: './email-update-listing.component.html',
  styleUrls: ['./email-update-listing.component.css']
})
export class EmailUpdateListingComponent implements OnInit{

  //date picker starts here
  dateRangePlaceholder: string = 'YYYY-MM-DD';
  calendar = inject(NgbCalendar);
	formatter = inject(NgbDateParserFormatter);

	hoveredDate: NgbDate | null = null;
	fromDate: NgbDate | null = null;
	toDate: NgbDate | null = null;

  selectedDate='YYYY-MM-DD'

  onDateInputChange(event: any) {
    const inputValue = event.target.value;
    if (!inputValue.trim()) {
      this.clearDatepicker();
    }
  }

  //Clear Date Picker
  clearDatepicker() {
    this.fromDate = null;
    this.toDate = null;
    this.selectedDate = "";
    // this.updateSelectedDate();
  }

  updateSelectedDate() {
    this.selectedDate =
      this.fromDate && this.toDate
        ? this.formatter.format(this.fromDate) + ' - ' + this.formatter.format(this.toDate)
        : "";
  }

	onDateSelection(date: NgbDate) {

    console.log(this.selectedDate+" Date");
		if (!this.fromDate && !this.toDate) {
			this.fromDate = date;
		} else if (this.fromDate && !this.toDate && date && date.after(this.fromDate)) {
			this.toDate = date;
		} else {
			this.toDate = null;
			this.fromDate = date;
		}
    this.selectedDate= this.formatter.format(this.fromDate) + ' - ' + this.formatter.format(this.toDate)
	}

	isHovered(date: NgbDate) {
		return (
			this.fromDate && !this.toDate && this.hoveredDate && date.after(this.fromDate) && date.before(this.hoveredDate)
		);
	}

	isInside(date: NgbDate) {
		return this.toDate && date.after(this.fromDate) && date.before(this.toDate);
	}

	isRange(date: NgbDate) {
		return (
			date.equals(this.fromDate) ||
			(this.toDate && date.equals(this.toDate)) ||
			this.isInside(date) ||
			this.isHovered(date)
		);
	}

	validateInput(currentValue: NgbDate | null, input: string): NgbDate | null {
		const parsed = this.formatter.parse(input);
		return parsed && this.calendar.isValid(NgbDate.from(parsed)) ? NgbDate.from(parsed) : currentValue;
	}

//date picker ends here
  constructor(private adminloginservice:AdminLoginService,private service :EmailUpdateListingService,
    private router:Router,private loader:SpinnerService,private toastr:ToastrService,private authService:AuthServiceService ) {}
  customers: EmilListing[] = [];
  date : any;
  token="";

  page : number=1;
  totalRecords : number=0;
  itemsPerPage = 10;
  tableSize : number = 10;
  tableSizes : any = [5,10,15,20]

  selectedCheckboxValues: number[] = [];

  updateSelectedCheckboxValues(id: number | undefined) {
    if (id === undefined) {
      console.log("id is undefined");
      return; // Ignore undefined values
    }
    const index = this.selectedCheckboxValues.indexOf(id);
    if (index === -1) {
      // Checkbox is checked, add the ID to the array
      this.selectedCheckboxValues.push(id);
    } else {
      // Checkbox is unchecked, remove the ID from the array
      this.selectedCheckboxValues.splice(index, 1);
    }
    this.logSelectedIds();
  }

  logSelectedIds() {
    console.log("<-----selected ids ------> ", this.selectedCheckboxValues);
  }
  onTableDataChange(event : any){
    this.page = event;
    this.search();
  }
  onTableSizeChange(event : any):void{
    this.tableSize=event.target.value;
    this.page = 1;
    this.search();
  }
  ngOnInit(): void {
    this.search();
    this.token =sessionStorage.getItem('token')??'';
    if (this.authService.isTokenExpired(this.token)) {
      this.adminloginservice.logout();
      console.log("Token expired");
    }
  }



  goHome(){
    this.router.navigate(['\dashboard']);
  }

    //padding zero for month and day
    private padNumber(value: number | undefined): string {
      return value !== undefined ? String(value).padStart(2, '0') : '';
    }
  search(){
    let noerror=false;
    const fromDateString: string | undefined = this.fromDate
      ? `${this.fromDate?.year}-${this.padNumber(this.fromDate?.month)}-${this.padNumber(this.fromDate?.day)}`
      : undefined;

      const toDateString: string | undefined= this.toDate
      ? `${this.toDate?.year}-${this.padNumber(this.toDate?.month)}-${this.padNumber(this.toDate?.day)}`
      : undefined;

      if(fromDateString!=undefined && toDateString==undefined){
        noerror=true;
        this.toastr.error("Please select end date.");
      }

    this.service.getEmailList(fromDateString,toDateString).subscribe(
      (response : any) => {
        if (response && response.response && Array.isArray(response.response)) {
          this.customers = response.response;
          this.totalRecords=this.customers.length;

        } else {
          console.error('Invalid API response format:', response);
        }
      },
      (error) => {
        this.toastr.error(error.error.message, 'Error');
        console.error('Error fetching data:', error);
      }
    );
  }
idGroup:number[]=[];
  //download email
  downloadEmail() {

    console.log("Before if-else block - selectedCheckboxValues:", this.selectedCheckboxValues, "data2:", this.customers);

    if (this.selectedCheckboxValues == null || this.selectedCheckboxValues.length === 0) {
      this.idGroup = this.customers.map(item => item.id);
    } else {
      this.idGroup = this.selectedCheckboxValues;
    }
    console.log("After if-else block - idGroup:", this.idGroup);

      const params = new HttpParams()
      .append('selectedDate', this.selectedDate);
      this.loader.requestStarted();
    this.adminloginservice.downloadEmail( this.idGroup ,params).subscribe(
      (response: any) =>{
        // Handle the blob data
        const blobUrl = URL.createObjectURL(response);
        // Create a link and trigger download
        const link = document.createElement('a');
        link.href = blobUrl;
        link.download = 'metro-email.zip';
        document.body.appendChild(link);
        link.click();
        document.body.removeChild(link);
        this.loader.requestEnded();
        this.toastr.success('Download complete', 'Success');
        },
        (error) => {
        this.loader.requestEnded();
          console.log("2")
          this.toastr.error('Unable to download', 'Error');
        }
    );
  }


  logout(){
    this.adminloginservice.logout();
  }

}
export interface EmilListing{
  id:number;
  idString:any;
   createdOn :any;
   createdOnString:any;
	 cardNo : string;
	 email : string;
	 companyName : string;
}
