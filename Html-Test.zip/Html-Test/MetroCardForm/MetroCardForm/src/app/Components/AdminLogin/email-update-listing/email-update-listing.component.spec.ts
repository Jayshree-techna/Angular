import { ComponentFixture, TestBed } from '@angular/core/testing';

import { EmailUpdateListingComponent } from './email-update-listing.component';

describe('EmailUpdateListingComponent', () => {
  let component: EmailUpdateListingComponent;
  let fixture: ComponentFixture<EmailUpdateListingComponent>;

  beforeEach(() => {
    TestBed.configureTestingModule({
      declarations: [EmailUpdateListingComponent]
    });
    fixture = TestBed.createComponent(EmailUpdateListingComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
