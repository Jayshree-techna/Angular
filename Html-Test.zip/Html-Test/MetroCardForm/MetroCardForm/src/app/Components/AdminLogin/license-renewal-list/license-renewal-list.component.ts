import { HttpClient, HttpParams, HttpResponse } from '@angular/common/http';
import { Component, OnInit, inject } from '@angular/core';
import { Router } from '@angular/router';
import {
  NgbCalendar,
  NgbDate,
  NgbDateParserFormatter,
} from '@ng-bootstrap/ng-bootstrap';
import { ToastrService } from 'ngx-toastr';
import { AdminLoginService } from 'src/app/services/admin-login.service';
import { AuthServiceService } from 'src/app/services/auth-service.service';
import { LicenceRenewalService } from 'src/app/services/licence-renewal.service';
import { SpinnerService } from 'src/app/services/spinner.service';

@Component({
  selector: 'app-license-renewal-list',
  templateUrl: './license-renewal-list.component.html',
  styleUrls: ['./license-renewal-list.component.css'],
})
export class LicenseRenewalListComponent implements OnInit {

  //date picker starts here

  dateRangePlaceholder: string = 'YYYY-MM-DD';
  calendar = inject(NgbCalendar);
  formatter = inject(NgbDateParserFormatter);

  hoveredDate: NgbDate | null = null;
  fromDate: NgbDate | null = null;
  toDate: NgbDate | null = null;

  selectedDate = 'YYYY-MM-DD';

  onDateInputChange(event: any) {
    const inputValue = event.target.value;
    if (!inputValue.trim()) {
      this.clearDatepicker();
    }
  }

  //Clear Date Picker
  clearDatepicker() {
    this.fromDate = null;
    this.toDate = null;
    this.selectedDate = "";
  }

  onDateSelection(date: NgbDate) {
    if (!this.fromDate && !this.toDate) {
      this.fromDate = date;
    } else if (
      this.fromDate &&
      !this.toDate &&
      date &&
      date.after(this.fromDate)
    ) {
      this.toDate = date;
    } else {
      this.toDate = null;
      this.fromDate = date;
    }
    this.selectedDate =
      this.formatter.format(this.fromDate) +
      ' - ' +
      this.formatter.format(this.toDate);
  }

  isHovered(date: NgbDate) {
    return (
      this.fromDate &&
      !this.toDate &&
      this.hoveredDate &&
      date.after(this.fromDate) &&
      date.before(this.hoveredDate)
    );
  }

  isInside(date: NgbDate) {
    return this.toDate && date.after(this.fromDate) && date.before(this.toDate);
  }

  isRange(date: NgbDate) {
    return (
      date.equals(this.fromDate) ||
      (this.toDate && date.equals(this.toDate)) ||
      this.isInside(date) ||
      this.isHovered(date)
    );
  }

  validateInput(currentValue: NgbDate | null, input: string): NgbDate | null {
    const parsed = this.formatter.parse(input);
    return parsed && this.calendar.isValid(NgbDate.from(parsed))
      ? NgbDate.from(parsed)
      : currentValue;
  }
  //date picker ends here


  selectedCheckboxValues: number[] = [];

  updateSelectedCheckboxValues(id: number | undefined) {
    if (id === undefined) {
       console.log("id is undefined");
      return; // Ignore undefined values
    }
    const index = this.selectedCheckboxValues.indexOf(id);
    if (index === -1) {
      // Checkbox is checked, add the ID to the array
      this.selectedCheckboxValues.push(id);
    } else {
      // Checkbox is unchecked, remove the ID from the array
      this.selectedCheckboxValues.splice(index, 1);
    }
    this.logSelectedIds();
  }

  logSelectedIds() {
    console.log("<-----selected ids ------> ", this.selectedCheckboxValues);
  }
  post: any;
  constructor(
    private adminloginservice: AdminLoginService,
    private service: LicenceRenewalService,
    private http: HttpClient,
    private router: Router,
    private toastr: ToastrService,
    private loader: SpinnerService,
    private authService: AuthServiceService
  ) {}
  ngOnInit(): void {
    this.getLicenseList();
    this.token =sessionStorage.getItem('token')??'';
    if (this.authService.isTokenExpired(this.token)) {
      this.adminloginservice.logout();
      console.log("Token expired");
    }
  }
  data2: LicenceRenewalListing[] = [];
  date: any;
  token="";

  page: number = 1;
  totalRecords: number = 0;
  itemsPerPage = 10;
  tableSize: number = 10;
  tableSizes: any = [5, 10, 15, 20];

  onTableDataChange(event: any) {
    this.page = event;
    this.getLicenseList();
  }

  onTableSizeChange(event: any): void {
    this.tableSize = event.target.value;
    this.page = 1;
    this.getLicenseList();
  }

  goToHome() {
    this.router.navigate(['dashboard']);
  }
  logout() {
    this.adminloginservice.logout();
  }
  private padNumber(value: number | undefined): string {
    // Ensure the number is at least two digits by adding leading zeros if needed
    return value !== undefined ? String(value).padStart(2, '0') : '';
  }

  getLicenseList() {
    const fromDateString: string | undefined = this.fromDate
      ? `${this.fromDate?.year}-${this.padNumber(
          this.fromDate?.month
        )}-${this.padNumber(this.fromDate?.day)}`
      : undefined;

    const toDateString: string | undefined = this.toDate
      ? `${this.toDate?.year}-${this.padNumber(
          this.toDate?.month
        )}-${this.padNumber(this.toDate?.day)}`
      : undefined;

    this.service.getLicenseList(fromDateString, toDateString).subscribe(
      (response: any) => {
        if (response && response.response && Array.isArray(response.response)) {
          this.data2 = response.response;
          this.totalRecords = this.data2.length;
        } else {
          console.error('Invalid API response format:', response);
          this.toastr.error('Invalid API response format', 'Error');
        }
      },
      (error) => {
        this.toastr.error(error.error.message, 'Error');
      }
    );
  }

  idGroup:number[]=[];
  //download license data
  downloadLicense() {

    console.log("Before if-else block - selectedCheckboxValues:", this.selectedCheckboxValues, "data2:", this.data2);

    if (this.selectedCheckboxValues == null || this.selectedCheckboxValues.length === 0) {
      this.idGroup = this.data2.map(item => item.id);
    } else {
      this.idGroup = this.selectedCheckboxValues;
    }
    console.log("After if-else block - idGroup:", this.idGroup);

    const params = new HttpParams()
    .append('selectedDate', this.selectedDate);
    this.loader.requestStarted();

    this.adminloginservice.downloadLicense(this.idGroup,params).subscribe(
      (response: any) => {
      // Handle the blob data
      const blobUrl = URL.createObjectURL(response);
      // Create a link and trigger download
      const link = document.createElement('a');
      link.href = blobUrl;
      link.download = 'metro-license.zip';
      document.body.appendChild(link);
      link.click();
      document.body.removeChild(link);
      this.loader.requestEnded();
      this.toastr.success('Download complete', 'Success');
      },
      (error) => {
        this.loader.requestEnded();
        console.log("2")
        this.toastr.error('Unable to download', 'Error');
      }
    );
  }

  downloadLicenseFile(filename:string) {
    this.adminloginservice.downloadLicensePhoto(filename).subscribe(
      (response: Blob) => {
        const blob = new Blob([response], { type: 'application/octet-stream' });
        console.log('blob--->' + blob);
        const link = document.createElement('a');
        link.href = window.URL.createObjectURL(blob);
        link.download = filename;
        document.body.appendChild(link);

        link.click();

        document.body.removeChild(link);
        this.loader.requestEnded();
        this.toastr.success('Download complete', 'Success');
      },
      (error) => {
        this.loader.requestEnded();
        console.log('2');
        this.toastr.error('Unable to download', 'Error');
      }
    );
    }

    private handleFileDownload(response: HttpResponse<Blob>) {
      const contentDisposition = response.headers.get('Content-Disposition');
      if (contentDisposition) {
        const fileName = contentDisposition.split('filename=')[1].replace(/"/g, '');
        const blob = new Blob([response.body!], { type: 'application/octet-stream' });
        // Create a link element
        const link = document.createElement('a');
        link.href = window.URL.createObjectURL(blob);
        link.download = fileName;
        // Trigger a click event to initiate the download
        link.dispatchEvent(new MouseEvent('click'));
        // Clean up resources
        window.URL.revokeObjectURL(link.href);
      } else {
        console.error('Content-Disposition header not found in the response.');
      }
    }

}

export class LicenceRenewalListing {
  idString:string='';
  id:number=0;
  createdOnString: string='';
  cardNo: string='';
  mobile: string='';
  licenseType: string='';
  idProof:string='';
}
