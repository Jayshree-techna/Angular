import { ComponentFixture, TestBed } from '@angular/core/testing';

import { LicenseRenewalListComponent } from './license-renewal-list.component';

describe('LicenseRenewalListComponent', () => {
  let component: LicenseRenewalListComponent;
  let fixture: ComponentFixture<LicenseRenewalListComponent>;

  beforeEach(() => {
    TestBed.configureTestingModule({
      declarations: [LicenseRenewalListComponent]
    });
    fixture = TestBed.createComponent(LicenseRenewalListComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
