import { Component, OnInit } from '@angular/core';
import { AdminLoginService } from 'src/app/services/admin-login.service';
import { Router } from '@angular/router';
import { AuthServiceService } from 'src/app/services/auth-service.service';

@Component({
  selector: 'app-admin-dashboard',
  templateUrl: './admin-dashboard.component.html',
  styleUrls: ['./admin-dashboard.component.css']
})
export class AdminDashboardComponent implements OnInit{
  result : any;
  isAddon : boolean=true;
  isReferal : boolean = true;
  isEmail : boolean = true;
  isLicenc : boolean = true;
  isCustomerUpload:boolean=true;
  role : any;
  token="";

  constructor(private service: AdminLoginService, private router:Router,private authService:AuthServiceService) { }
emailListing() {
  this.router.navigate(['\emailList']);
}
licenselist() {
  this.router.navigate(['\licenseList']);
}
refer() {
  // this.router.navigate(['\refer']);
  this.router.navigateByUrl('referralList');
}
addonListing() {
 this.router.navigate(['\addonList']);
}

  customerUpload() {
  this.router.navigate(['\customerUpload']);
  }

  logout(){
    this.service.logout();

   }
  ngOnInit(): void {
     this.onSubmit();
     this.token =sessionStorage.getItem('token')??'';
    if (this.authService.isTokenExpired(this.token)) {
      this.service.logout();
      console.log("Token expired");
    }
  }

  onSubmit(){
    this.role=this.service.getRole();

    if(this.service.getRole()!= null){
      if(this.role === 'true'){
        this.isAddon=false;
        this.isEmail=false;
        this.isReferal=false;
        this.isCustomerUpload=false;
      }else if (this.role=== 'false'){
        this.isLicenc=false;

      }
    }

  }
}
