
import { Component, OnInit } from '@angular/core';
import { FormGroup, FormControl, Validators, FormBuilder } from '@angular/forms'
import { AdminLoginService } from 'src/app/services/admin-login.service';
import { Router } from '@angular/router';
import { ToastrService } from 'ngx-toastr';
import { AuthServiceService } from 'src/app/services/auth-service.service';

@Component({
  selector: 'app-admin-login',
  templateUrl: './admin-login.component.html',
  styleUrls: ['./admin-login.component.css']
})
export class AdminLoginComponent implements OnInit {

  title='ADMIN LOGIN';
  title2='WELCOME';
  isFormValid: boolean = false;
  token="";
  contactForm = new FormGroup({
    userName: new FormControl(),
    password: new FormControl()
  })
  constructor(private service: AdminLoginService, private fb: FormBuilder,
    private authService: AuthServiceService,private router: Router,private toster:ToastrService) {
    this.contactForm.reset();
  }
  ngOnInit(): void {
    this.contactForm = this.fb.group({
      userName: ['', Validators.required],
      password: ['', Validators.required]
    });

    this.contactForm.valueChanges.subscribe(() => {
      this.isFormValid = this.contactForm.valid;
    });

    this.token =sessionStorage.getItem('token')??'';
    if (this.authService.isTokenExpired(this.token)) {
      this.service.logout();
      console.log("Token expired");
    }
  }


  onSubmit() {

    if(this.contactForm.value.userName == null){
      this.toster.error("Please enter username")
    }else if(this.contactForm.value.userName != null && this.contactForm.value.password==null){
      this.toster.error("Please enter password")
    }else if(this.contactForm.value.userName== null && this.contactForm.value.password == null){
      this.toster.error("Please enter credentials")
    }
    else if ((this.contactForm.value.userName!= '' && this.contactForm.value.password != '') && (this.contactForm.value.userName != null && this.contactForm.value.password != null)) {
      this.service.doLogin(this.contactForm.value).subscribe(
        (response: any) => {
          if(response.status==200){
            const authorizationHeader = response.response.accessToken;

            console.log(response)
            if (authorizationHeader) {
            this.service.loginUser(authorizationHeader);
            this.service.setRole(response.response.isLicenace);
            this.router.navigate(['/dashboard']);
            }
          }else if(response.status==400){
            this.toster.error("Invalid credentials")
            this.contactForm.reset();
          }
        },
        error => {
          this.contactForm.reset();
          this.toster.error("Invalid credentials")
          console.log(error)
        });
    } else {
      this.toster.error("Please enter credentials");
    }

  }
}
