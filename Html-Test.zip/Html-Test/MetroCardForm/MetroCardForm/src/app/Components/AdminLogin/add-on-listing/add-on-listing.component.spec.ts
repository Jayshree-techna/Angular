import { ComponentFixture, TestBed } from '@angular/core/testing';

import { AddOnListingComponent } from './add-on-listing.component';

describe('AddOnListingComponent', () => {
  let component: AddOnListingComponent;
  let fixture: ComponentFixture<AddOnListingComponent>;

  beforeEach(() => {
    TestBed.configureTestingModule({
      declarations: [AddOnListingComponent]
    });
    fixture = TestBed.createComponent(AddOnListingComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
