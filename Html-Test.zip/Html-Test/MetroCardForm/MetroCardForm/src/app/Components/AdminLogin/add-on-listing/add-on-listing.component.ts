import { EmailUpdateListingService } from 'src/app/services/email-update-listing.service';

import { HttpParams } from '@angular/common/http';
import { Component, inject, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import {
  NgbCalendar,
  NgbDate,
  NgbDateParserFormatter,
} from '@ng-bootstrap/ng-bootstrap';
import { ToastrService } from 'ngx-toastr';
import { AddonCardFormService } from 'src/app/services/addon-card-form.service';
import { AdminLoginService } from 'src/app/services/admin-login.service';
import { AuthServiceService } from 'src/app/services/auth-service.service';
import { SpinnerService } from 'src/app/services/spinner.service';

@Component({
  selector: 'app-add-on-listing',
  templateUrl: './add-on-listing.component.html',
  styleUrls: ['./add-on-listing.component.css'],
})
export class AddOnListingComponent implements OnInit {
  len = 6;
  data: AddonListing[] = [];
  idGroup: number[] = [];
  token = '';

  constructor(
    private router: Router,
    private addonService: AddonCardFormService,
    private adminloginservice: AdminLoginService,
    private service: EmailUpdateListingService,
    private loader: SpinnerService,
    private toastr: ToastrService,
    private authService: AuthServiceService
  ) {}

  selectedCheckboxValues: number[] = [];

  updateSelectedCheckboxValues(id: number | undefined) {
    if (id === undefined) {
      console.log('id is undefined');
      return; // Ignore undefined values
    }
    const index = this.selectedCheckboxValues.indexOf(id);
    if (index === -1) {
      this.selectedCheckboxValues.push(id);
    } else {
      this.selectedCheckboxValues.splice(index, 1);
    }
    this.logSelectedIds();
  }

  logSelectedIds() {
    console.log('<-----selected ids ------> ', this.selectedCheckboxValues);
  }

  //date picker starts here

  dateRangePlaceholder: string = 'YYYY-MM-DD';
  calendar = inject(NgbCalendar);
  formatter = inject(NgbDateParserFormatter);

  hoveredDate: NgbDate | null = null;
  fromDate: NgbDate | null = null;
  toDate: NgbDate | null = null;

  selectedDate = 'YYYY-MM-DD';

  onDateInputChange(event: any) {
    const inputValue = event.target.value;
    if (!inputValue.trim()) {
      this.clearDatepicker();
    }
  }

  //Clear Date Picker
  clearDatepicker() {
    this.fromDate = null;
    this.toDate = null;
    this.selectedDate = '';
  }

  onDateSelection(date: NgbDate) {
    if (!this.fromDate && !this.toDate) {
      this.fromDate = date;
    } else if (
      this.fromDate &&
      !this.toDate &&
      date &&
      date.after(this.fromDate)
    ) {
      this.toDate = date;
    } else {
      this.toDate = null;
      this.fromDate = date;
    }
    this.selectedDate =
      this.formatter.format(this.fromDate) +
      ' - ' +
      this.formatter.format(this.toDate);
  }

  isHovered(date: NgbDate) {
    return (
      this.fromDate &&
      !this.toDate &&
      this.hoveredDate &&
      date.after(this.fromDate) &&
      date.before(this.hoveredDate)
    );
  }

  isInside(date: NgbDate) {
    return this.toDate && date.after(this.fromDate) && date.before(this.toDate);
  }

  isRange(date: NgbDate) {
    return (
      date.equals(this.fromDate) ||
      (this.toDate && date.equals(this.toDate)) ||
      this.isInside(date) ||
      this.isHovered(date)
    );
  }

  validateInput(currentValue: NgbDate | null, input: string): NgbDate | null {
    const parsed = this.formatter.parse(input);
    return parsed && this.calendar.isValid(NgbDate.from(parsed))
      ? NgbDate.from(parsed)
      : currentValue;
  }
  //date picker ends here

  dateFilterAddonList() {
    // this.addonService.AddonList
  }

  page: number = 1;
  totalRecords: number = 0;
  itemsPerPage = 10;

  tableSizes: any = [5, 10, 15, 20];

  ngOnInit(): void {
    this.search();
    this.token = sessionStorage.getItem('token') ?? '';
    if (this.authService.isTokenExpired(this.token)) {
      this.adminloginservice.logout();
      console.log('Token expired');
    }
  }

  goToHome() {
    this.router.navigate(['dashboard']);
  }
  logout() {
    this.adminloginservice.logout();
  }
  //padding zero for month and day
  private padNumber(value: number | undefined): string {
    return value !== undefined ? String(value).padStart(2, '0') : '';
  }
  search() {
    const fromDateString: string | undefined = this.fromDate
      ? `${this.fromDate?.year}-${this.padNumber(
          this.fromDate?.month
        )}-${this.padNumber(this.fromDate?.day)}`
      : undefined;

    const toDateString: string | undefined = this.toDate
      ? `${this.toDate?.year}-${this.padNumber(
          this.toDate?.month
        )}-${this.padNumber(this.toDate?.day)}`
      : undefined;

    this.service.getAddOnList(fromDateString, toDateString).subscribe(
      (response: any) => {
        if (response && response.response && Array.isArray(response.response)) {
          this.data = response.response;
          this.totalRecords = this.data.length;
        } else {
          console.error('Invalid API response format:', response);
        }
      },
      (error) => {
        this.toastr.error('Error fetching data', 'Error');
      }
    );
  }

  downloadPhoto(filename: string) {
    this.adminloginservice.downloadPhoto(filename).subscribe(
      (response: Blob) => {
        const blob = new Blob([response], { type: 'application/octet-stream' });
        console.log('blob--->' + blob);
        const link = document.createElement('a');
        link.href = window.URL.createObjectURL(blob);
        link.download = filename;
        document.body.appendChild(link);

        link.click();

        document.body.removeChild(link);
        this.loader.requestEnded();
        this.toastr.success('Download complete', 'Success');
      },
      (error) => {
        this.loader.requestEnded();
        console.log('2');
        this.toastr.error('Unable to download', 'Error');
      }
    );
  }

  downloadAddon() {
    console.log(
      'Before if-else block - selectedCheckboxValues:',
      this.selectedCheckboxValues,
      'data2:',
      this.data
    );

    if (
      this.selectedCheckboxValues == null ||
      this.selectedCheckboxValues.length === 0
    ) {
      this.idGroup = this.data.map((item) => item.id);
    } else {
      this.idGroup = this.selectedCheckboxValues;
    }
    console.log('After if-else block - idGroup:', this.idGroup);

    const params = new HttpParams().append('selectedDate', this.selectedDate);
    this.loader.requestStarted();

    this.adminloginservice.downloadAddon(this.idGroup, params).subscribe(
      (response: any) => {
        // Handle the blob data
        const blobUrl = URL.createObjectURL(response);
        // Create a link and trigger download
        const link = document.createElement('a');
        link.href = blobUrl;
        link.download = 'metro-addon-download.zip';
        document.body.appendChild(link);
        link.click();
        document.body.removeChild(link);
        this.loader.requestEnded();
        this.toastr.success('Download complete', 'Success');
      },
      (error) => {
        this.loader.requestEnded();
        console.log('2');
        this.toastr.error('Unable to download', 'Error');
      }
    );
  }


  private handleFileDownload(response: any) {
    const contentDisposition = response.headers.get('Content-Disposition');
    if (contentDisposition) {
      const fileName = contentDisposition
        .split('filename=')[1]
        .replace(/"/g, '');
      const blob = new Blob([response.body!], {
        type: 'application/octet-stream',
      });
      // Create a link element
      const link = document.createElement('a');
      link.href = window.URL.createObjectURL(blob);
      link.download = fileName;
      // Trigger a click event to initiate the download
      link.dispatchEvent(new MouseEvent('click'));
      // Clean up resources
      window.URL.revokeObjectURL(link.href);
    } else {
      console.error('Content-Disposition header not found in the response.');
    }
  }
}

export interface AddonListing {
  idString: string;
  id: number;
  createdOnString: any;
  addOnNumber: number;
  email: string;
  applicantName: string;
  mobileNumber: string;
  gender: string;
  consent: string;
  consentString: string;
  positionName: string;
  cardNo: number;
  cardholderNo: number;
  photoId: string;
}
