import { AdminLoginService } from './../../services/admin-login.service';
import { Component, OnInit, ViewChild } from '@angular/core';
import { Router } from '@angular/router';
import { ToastrService } from 'ngx-toastr';
import { AuthServiceService } from 'src/app/services/auth-service.service';
import { CustomerUploadService } from 'src/app/services/customer-upload.service';

@Component({
  selector: 'app-customer-upload',
  templateUrl: './customer-upload.component.html',
  styleUrls: ['./customer-upload.component.css'],
})
export class CustomerUploadComponent implements OnInit {
  @ViewChild('fileInput')
  fileInp: any;

  table_body = false;
  errorField = true;
  file: any = undefined;
  formdata: any;
  button: string = 'UPLOAD';
  customerData: any;
  isProcess: boolean = false;
  uploadLength: any = 'There are 0 records available';
  token=""

  page: number = 1;
  totalRecords: number = 0;
  tableSize: number = 10;
  tableSizes: any = [5, 10, 15, 20];

  constructor(
    private customerUploadService: CustomerUploadService,
    private _router: Router,
    private _toaster: ToastrService,
    private adminloginservice:AdminLoginService,
    private authService:AuthServiceService
  ) {}

  ngOnInit(): void {
    this.customerUploadService.customerHistory().subscribe((res: any) => {
      if (res.status == 200) {
        console.log(res);
        this.uploadLength = res.body.message;
      }
    });

    this.token =sessionStorage.getItem('token')??'';
    if (this.authService.isTokenExpired(this.token)) {
      this.adminloginservice.logout();
      console.log("Token expired");
    }
  }

  getFile(event: any) {
    this.file = event.target.files[0];
    console.log(this.file.name);

    if (!this.file) {
      this.fileInp.nativeElement.value = '';
    }
  }

  apiCall() {
    if (this.button == 'UPLOAD') {
      this.upload();
    }
    if (this.button == 'VALIDATE') {
      this.validate();
    }
    if (this.button == 'PROCESS') {
      this.process();
    }
  }

  upload() {
    if (!this.file) {
      this._toaster.error('please select the file');
    } else {
      const formdata = new FormData();
      formdata.append('file', this.file, this.file.name);
      console.log(formdata);
      this.customerUploadService.uploadFile(formdata).subscribe(
        (res: any) => {
          if (res.status == 200) {
            console.log('upload--->' + res.body.message);
            this._toaster.success(res.body.message);
            console.log(res);
            // this.uploadLength = res.body.customerUploadResponse.length
            this.uploadLength =
              'There are ' +
              res.body.customerUploadResponse.length +
              ' record available';
            this.button = 'VALIDATE';
          }
        },
        (err) => {
          if (err.status == 401) this._router.navigateByUrl('login');
          else this._toaster.error(err.body.message);
        }
      );
    }
  }

  validate() {
    this.customerUploadService.validate().subscribe(
      (res: any) => {
        if (res.status == 200) {
          console.log(res);
          this.customerData = res.body.customerUploadResponse;
          // console.log(this.customerData)
          this._toaster.success(res.body.message);
          for (let a = 0; a < this.customerData.length; a++) {
            this.isProcess = this.customerData[a]['isError'] === 1;
            console.log(this.isProcess);
          }
          if (!this.isProcess) {
            this.button = 'PROCESS';
          }
          this.errorField = false;
        }
      },
      (err: any) => {
        if (err.status == 401) this._router.navigateByUrl('login');
        else this._toaster.error(err.body.message);
      }
    );
  }
  process() {
    this.customerUploadService.process().subscribe(
      (res: any) => {
        if (res.status == 200) {
          this._toaster.success(res.body.message);
          this.errorField = true;
          this.button = 'UPLOAD';
          this.uploadLength = 'Customer data uploaded successfully.';
          this.fileInp.nativeElement.value = '';
        }
      },
      (err: any) => {
        if (err.status == 401) this._router.navigateByUrl('login');
        else this._toaster.error(err.body.message);
      }
    );
  }

  clear() {
    this.customerUploadService.clearApi().subscribe(
      (data: any) => {
        if (data.status == 200) {
          this._toaster.success(data.body.message);
          this.button = 'UPLOAD';
          this.errorField = true;
          this.uploadLength = 'Cleared successfully.';
          this.fileInp.nativeElement.value = '';
        }
      },
      (err: any) => {
        if (err.status == 401) this._router.navigateByUrl('login');
        else this._toaster.error(err.body.message);
      }
    );
  }

  logoutToLogin() {
    console.log('into logout');
    sessionStorage.clear();
    this._router.navigateByUrl('login');
    this._toaster.success('Log out success.');
  }
  toHome() {
    this._router.navigateByUrl('dashboard');
  }
}
