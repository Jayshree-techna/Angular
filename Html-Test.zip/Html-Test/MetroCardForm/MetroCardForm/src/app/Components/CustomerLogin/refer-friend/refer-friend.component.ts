import { Component } from '@angular/core';
import { FormBuilder } from '@angular/forms';
import { Router } from '@angular/router';
import { ToastrService } from 'ngx-toastr';
import { AdminLoginService } from 'src/app/services/admin-login.service';
import { AuthServiceService } from 'src/app/services/auth-service.service';
import { CustomerUploadService } from 'src/app/services/customer-upload.service';
import { DataService } from 'src/app/services/data.service';

@Component({
  selector: 'app-refer-friend',
  templateUrl: './refer-friend.component.html',
  styleUrls: ['./refer-friend.component.css'],
})
export class ReferFriendComponent {


  title = 'Refer a friend';
  title2 = 'Please Enter Your Details';
  button = true;
  userDetails = this.dataService.getEmailValue();
  eligibleRefCount: number = 0;

  referralCustomer: any;

  custId: number = 0;
  custIdString: any = '';
  companyName: any = '';
  mobile: any = '';
  email: any = '';
  refString: any = '';
  token="";

  constructor(
    private toastr: ToastrService,
    private customerService: CustomerUploadService,
    private dataService: DataService,
    private fb: FormBuilder,
    private router:Router,
    private adminService:AdminLoginService,
    private authService: AuthServiceService
  ) {
    this.custIdString = sessionStorage.getItem('custId');
    this.custId = parseInt(this.custIdString, 10);
    this.companyName = sessionStorage.getItem('companyName');
    this.mobile = sessionStorage.getItem('mobile');
    this.email = sessionStorage.getItem('email');
    this.refString = sessionStorage.getItem('referCount');
    this.eligibleRefCount = parseInt(this.refString, 10);

    this.initializeReferralCustomer();
    // this. isSaveButtonDisabled();
  }

  // customerReferral: any;

  // ngOnInit() {
  //   this.customerReferral = this.fb.group({
  //     // Define your form controls and their initial values and validators here
  //     referredCustomerName1: ['', Validators.required],
  //     referredCustomerMobile1: ['', Validators.required],
  //     referredCustomerEmail1: ['', [Validators.required, Validators.email]],
  //     // ... other form controls
  //   });
  // }
  ngOnit() {
    this.token =sessionStorage.getItem('token')??'';
    if (this.authService.isTokenExpired(this.token)) {
      this.adminService.logout();
      console.log("Token expired");
    }
  }
  private initializeReferralCustomer(): void {
    this.referralCustomer = {
      customerId: this.custId,
      referredCustomerName: this.companyName,
      referredCustomerMobile: this.mobile,
      referredCustomerEmail: this.email,
      referralDto: [
        {
          referredName: '',
          referredMobile: '',
          referredEmail: '',
        },
      ],
    };
  }

  customerSelectedCount = 1;
  formCount = 2;
  secondForm = false;
  thirdForm = false;
  forthForm = false;
  fifthForm = false;

  firstAddButton = true;
  secondAddButton = true;
  thirdAddButton = true;
  forthAddButton = true;
  fifthAddButton = true;

  secondDelButton = false;
  thirdDelButton = false;
  forthDelButton = false;
  fifthDelButton = false;

  // saveButtonDisabled=true;

  // isSaveButtonDisabled(): boolean {
  //   return false;
  // return this.referralCustomer.referralDto && this.referralCustomer.referralDto.length > 0;
  // }

  showSecondForm() {
    if (this.formCount <= this.eligibleRefCount) {
      this.formCount++;
      this.customerSelectedCount++;
      this.firstAddButton = false;
      this.secondForm = true;
      if (this.referralCustomer.referralDto.length < 5) {
        this.referralCustomer.referralDto.push({
          referredName: '',
          referredMobile: '',
          referredEmail: '',
        });
      }
    } else {
      this.toastr.error('You can refer only one person');
    }
    console.log(
      'eligible count ' +
        this.eligibleRefCount +
        'slected ' +
        this.customerSelectedCount
    );
  }

  showThirdForm() {
    if (this.formCount <= this.eligibleRefCount) {
      this.formCount++;
      this.customerSelectedCount++;
      this.secondAddButton = false;
      this.thirdForm = true;
      if (this.referralCustomer.referralDto.length < 5) {
        this.referralCustomer.referralDto.push({
          referredName: '',
          referredMobile: '',
          referredEmail: '',
        });
      }
    } else {
      this.toastr.error('You can refer only two person');
    }
    console.log(
      'eligible count ' +
        this.eligibleRefCount +
        'slected ' +
        this.customerSelectedCount
    );
  }
  showForthForm() {
    if (this.formCount <= this.eligibleRefCount) {
      this.formCount++;
      this.customerSelectedCount++;
      this.thirdAddButton = false;
      this.forthForm = true;
      if (this.referralCustomer.referralDto.length < 5) {
        this.referralCustomer.referralDto.push({
          referredName: '',
          referredMobile: '',
          referredEmail: '',
        });
      }
    } else {
      this.toastr.error('You can refer only three person');
    }
    console.log(
      'eligible count ' +
        this.eligibleRefCount +
        'slected ' +
        this.customerSelectedCount
    );
  }
  showFifthForm() {
    if (this.formCount <= this.eligibleRefCount) {
      this.formCount++;
      this.customerSelectedCount++;
      this.forthAddButton = false;
      this.fifthForm = true;
      if (this.referralCustomer.referralDto.length < 5) {
        this.referralCustomer.referralDto.push({
          referredName: '',
          referredMobile: '',
          referredEmail: '',
        });
      }
    } else {
      this.toastr.error('You can refer only four person');
    }
    console.log(
      'eligible count ' +
        this.eligibleRefCount +
        'slected ' +
        this.customerSelectedCount
    );
  }

  hideFifthForm() {
    this.customerSelectedCount--;
    this.fifthForm = false;
    this.forthAddButton = true;
    this.referralCustomer.referralDto.splice(4, 1);
    console.log(
      'eligible count ' +
        this.eligibleRefCount +
        'slected ' +
        this.customerSelectedCount
    );
  }
  hideForthForm() {
    this.customerSelectedCount--;
    this.forthForm = false;
    this.thirdAddButton = true;
    this.referralCustomer.referralDto.splice(3, 1);
    console.log(
      'eligible count ' +
        this.eligibleRefCount +
        'slected ' +
        this.customerSelectedCount
    );
  }
  hideThirdForm() {
    this.customerSelectedCount--;
    this.thirdForm = false;
    this.secondAddButton = true;
    this.referralCustomer.referralDto.splice(2, 1);
    console.log(
      'eligible count ' +
        this.eligibleRefCount +
        'slected ' +
        this.customerSelectedCount
    );
  }
  hideSecondForm() {
    this.customerSelectedCount--;
    this.secondForm = false;
    this.firstAddButton = true;
    this.referralCustomer.referralDto.splice(1, 1);
    console.log(
      'eligible count ' +
        this.eligibleRefCount +
        'slected ' +
        this.customerSelectedCount
    );
  }

  referFriendSave() {
    // this.referralCustomer.customerId = this.dataService.getEmailValue().id;

    // if(!this.customerReferral.valid &&this.customerReferral.value.referredCustomerName1 == null
    //   &&this.customerReferral.value.referredCustomerMobile1  == null&&
    //   this.customerReferral.value.referredCustomerEmail1 ){

    //   this.toastr.error('Enter referral details to proceed');
    //   return;
    // }

    // if (this.customerSelectedCount > 0 && this.eligibleRefCount > 0) {
    //   for (let i = 0; i < this.customerSelectedCount; i++) {
    //     const referral = this.referralCustomer.referralDto[i];
    //     console.log(referral);
    //     if (
    //       !referral ||
    //       !referral.referredCustomerName ||
    //       referral.referredCustomerName.trim().length === 0 ||
    //       !referral.referredEmail ||
    //       referral.referredEmail.trim().length === 0 ||
    //       !referral.referredCustomerMobile ||
    //       referral.referredCustomerMobile.trim().length === 0
    //     ) {

    //       this.toastr.error('Enter referral details to proceed');
    //       console.log('No data at ' + i);
    //       return;
    //     }
    //   }

    //   if (this.referralCustomer.referralDto.length === 0) {
    //     this.toastr.error('Enter referral details to proceed');
    //     console.log('empty referral');
    //     return;
    //   }
    // }

    console.log(this.referralCustomer);
    console.log(this.referralCustomer.referralDto);

    this.customerService.saveReferrals(this.referralCustomer).subscribe(
      (data: any) => {
        console.log(data);
        this.toastr.success("Referral saved", 'Success');
        this.router.navigateByUrl('customerDashboard');
      },
      (error) => {
        this.toastr.error(error.error.message, 'Error');
      }
    );
  }
}
