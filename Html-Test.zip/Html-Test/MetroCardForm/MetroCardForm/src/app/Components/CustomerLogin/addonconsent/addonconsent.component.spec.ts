import { ComponentFixture, TestBed } from '@angular/core/testing';

import { AddonconsentComponent } from './addonconsent.component';

describe('AddonconsentComponent', () => {
  let component: AddonconsentComponent;
  let fixture: ComponentFixture<AddonconsentComponent>;

  beforeEach(() => {
    TestBed.configureTestingModule({
      declarations: [AddonconsentComponent]
    });
    fixture = TestBed.createComponent(AddonconsentComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
