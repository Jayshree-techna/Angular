import { ComponentFixture, TestBed } from '@angular/core/testing';

import { AddonListingComponent } from './addon-listing.component';

describe('AddonListingComponent', () => {
  let component: AddonListingComponent;
  let fixture: ComponentFixture<AddonListingComponent>;

  beforeEach(() => {
    TestBed.configureTestingModule({
      declarations: [AddonListingComponent]
    });
    fixture = TestBed.createComponent(AddonListingComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
