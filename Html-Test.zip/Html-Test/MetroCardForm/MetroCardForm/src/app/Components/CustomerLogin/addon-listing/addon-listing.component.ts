import { Component, Input, OnInit } from '@angular/core';
import { FormBuilder, FormControl, FormGroup, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { ToastrService } from 'ngx-toastr';
import { AddonForm, AddonSubmit } from 'src/app/model/AddonForm';
import { EmailUpdate } from 'src/app/model/EmailUpdate';
import { AddonCardFormService } from 'src/app/services/addon-card-form.service';
import { AdminLoginService } from 'src/app/services/admin-login.service';
import { AuthServiceService } from 'src/app/services/auth-service.service';
import { OtpService } from 'src/app/services/otp.service';
import { DataService } from '../../../services/data.service';

@Component({
  selector: 'app-addon-listing',
  templateUrl: './addon-listing.component.html',
  styleUrls: ['./addon-listing.component.css']
})
export class AddonListingComponent implements OnInit {
  title = 'Addon Listing';
  title2 = 'Eligible Add-on cards - ' + sessionStorage.getItem('addonCount');
  totalForms = 1;
  addonForms: FormGroup[] = [];
  addonData: any[] = [];
  files: File[] = [];
  result: position[] = [];
  isGenarateOtp = false;
  isOtp = false;
  isValidOtp = false;
  isTermsAndCondition = false;
  email: EmailUpdate = this.dataService.getEmailValue();
  otp = '';
  addonCountString = sessionStorage.getItem('addonCount');
  maxForms: number = this.addonCountString ? parseInt(this.addonCountString, 10) : 0;

  constructor(
    private addonDetailsService: AddonCardFormService,
    private router: Router,
    private adminService: AdminLoginService,
    private fb: FormBuilder,
    private otpService: OtpService,
    private toster: ToastrService,
    private dataService: DataService,
    private authService: AuthServiceService
  ) { }

  ngOnInit(): void {
    this.onSubmit1()
    this.addonForms.push(this.initializeAddonForm());
  }

  initializeAddonForm(): FormGroup {
    return this.fb.group({
      fullName: ['', [Validators.required, Validators.minLength(2)]],
      mobile: ['', [Validators.required, Validators.minLength(10), Validators.maxLength(10)]],
      email: ['', [Validators.required, Validators.pattern('^[\\w-\\+]+(\\.[\\w]+)*@[\\w-]+(\\.[\\w]+)*(\\.[a-z]{2,})$')]],
      gender: [''],
      position: ['']
    });
  }

  getFormCountArray(): number[] {
    return new Array(this.totalForms);
  }

  onFileChange(event: any, index: number): void {
    const files: FileList = event.target.files;
    if (files.length > 0) {
      const selectedFile: File = files[0];
      if (index >= 0 && index < this.files.length) {
        this.files[index] = selectedFile;
      } else {
        this.files.push(selectedFile);
      }
    }
  }

  isFormValid(): boolean {
    const form = this.addonForms[this.addonForms.length - 1];

    if (form) {
      return form.valid &&
        form.get('fullName')?.value &&
        form.get('mobile')?.value &&
        form.get('email')?.value &&
        form.get('gender')?.value &&
        form.get('position')?.value;
    }

    return false;
  }



  getFullName(formIndex: number): FormControl {
    return this.addonForms[formIndex].get('fullName') as FormControl;
  }

  getMobile(formIndex: number): FormControl {
    return this.addonForms[formIndex].get('mobile') as FormControl;
  }

  getEmail(formIndex: number): FormControl {
    return this.addonForms[formIndex].get('email') as FormControl;
  }

  getGender(formIndex: number): FormControl {
    return this.addonForms[formIndex].get('gender') as FormControl;
  }

  getPosition(formIndex: number): FormControl {
    return this.addonForms[formIndex].get('position') as FormControl;
  }

  incrementFormCount(formValue: any, index: number): void {
    if (this.addonForms[index].valid) {
      this.totalForms++;
      this.addonData.push(formValue);
      this.addonForms.push(this.initializeAddonForm());
      this.isTermsAndCondition = true
    } else {
      this.toster.warning('Please fill the current form correctly');
      this.isTermsAndCondition = false
    }
  }

  deleteForm(index: number): void {
    if (this.totalForms > 1) {
      this.totalForms--;
      this.addonData.splice(index, 1);
      this.addonForms.splice(index, 1);
    } else {
      this.toster.warning('At least one form is required');
    }
  }

  onSubmit1() {
    this.adminService.getPosition().subscribe(
      (response: any) => {
        if (response && response.response && Array.isArray(response.response)) {
          this.result = response.response;
        } else {
          console.error('Invalid API response format:', response);
        }
      },
      (error) => {
        console.log('error');
      }
    );
  }

  handleCheckboxChangeTC() {
    if (this.isGenarateOtp) {
      this.isGenarateOtp = false;
      this.isOtp = false;
      this.isValidOtp = false;
    } else {
      this.isGenarateOtp = true;
    }
  }
  handleCheckboxChangeGO() {
    if (this.isOtp) {
      this.isOtp = false;
      this.isValidOtp = false;
    } else {
      this.isOtp = true;
    }
    if (this.maxForms === 0) {
      this.toster.error('Cannot addon, as eligibility = 0 ', 'Error');
    } else if (this.isOtp == true) {
      if (this.email.id != 0) {
        this.otpService
          .generateMainOtp(this.email.id, this.email.mobile)
          .subscribe(
            (data: any) => {
              this.toster.success(data.message, 'OTP generated successfully');
            },
            (err) => {
              this.toster.error(err.error.message, 'OTP generation failed');
            }
          );
      }
    }
  }

  validateOtp() {
    let customerId = localStorage.getItem('id');
    let customerIdNumber = customerId ? parseInt(customerId, 10) : 0;
    console.log(this.email.id);
    if (this.email.id != 0) {
      this.otpService.validateMainMailOtp(this.email.id, this.otp).subscribe(
        (data: any) => {
          this.toster.success("Valid OTP", '');
          this.isValidOtp = true
          this.isOtp = false
          // this.onSubmit();
        },
        (err) => {
          this.toster.error('Invalid OTP', "");
        }
      );
    }
  }

  onSubmit() {
    const addonSubmit: any = {
      customerId: sessionStorage.getItem('custId'),
      addonForm: this.addonForms.map(form => ({
        addonApplicantName: form.get('fullName')?.value,
        addonApplicantMobile: form.get('mobile')?.value,
        addonApplicantEmail: form.get('email')?.value,
        addonApplicantGender: form.get('gender')?.value,
        addonPositionId: form.get('position')?.value,
      })),
    };

    let json: any = {};
    json.customerId = sessionStorage.getItem('custId');
    json.addonForm = addonSubmit.addonForm;


    let jsonString: string = JSON.stringify(json);
    type jsonType = typeof json;
    let dto: FormData = new FormData();

    dto.append('dto', JSON.stringify(json));

    for (let i = 0; i < this.files.length; i++) {
      const fieldName = `file${i + 1}`;
      const file = this.files[i];

      dto.append(fieldName, file, file.name);
    }

    this.addonDetailsService
      .addAddonDetailsList(dto)
      .subscribe(
        (response: any) => {
          if (response.status == 200 || response.status == '200') {
            this.toster.success('Addon details added successfully');
            this.router.navigate(['/customerDashboard']);
          }
        },
        (error) => {
          if (error.status == 400 || error.status == '400') {
            this.toster.error(error.message);
            console.log("-----------------" + error.message);
          }
          this.router.navigateByUrl('/error');
        }
      );
  }
}
export interface position {
  id: number;
  positionId: string;
  positionName: string;
}
