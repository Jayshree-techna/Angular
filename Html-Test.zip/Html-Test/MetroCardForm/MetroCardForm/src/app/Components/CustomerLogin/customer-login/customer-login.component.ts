import { Component } from '@angular/core';
import { FormBuilder, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { ToastrService } from 'ngx-toastr';
import { AdminLoginService } from 'src/app/services/admin-login.service';
import { AuthServiceService } from 'src/app/services/auth-service.service';
import { CustomerLoginService } from 'src/app/services/customer-login.service';
import { SpinnerService } from 'src/app/services/spinner.service';


@Component({
  selector: 'app-customer-login',
  templateUrl: './customer-login.component.html',
  styleUrls: ['./customer-login.component.css']
})
export class CustomerLoginComponent {

  title: string = 'Apply now for the Add - on Metro Cards or Refer a friend in just 3 simple steps';
  title2: string = 'please enter the details to proceed';
  error = false
  errorDesc = ''
  errorDesc2=''
  token=""
  constructor(private _fb: FormBuilder, private customerLoginService: CustomerLoginService,
    private authService:AuthServiceService,private adminService: AdminLoginService,
    private _router: Router,private _toaster:ToastrService,private loader:SpinnerService) {
    sessionStorage.clear();
    loader.requestEnded();
  }


  costumerLogin = this._fb.group({
    mobileNumber: [null],
    cardNumber: [null],
    cardHolderNumber: ['', Validators.required]
  })
  ngOnit() {
    this.token =sessionStorage.getItem('token')??'';
    if (this.authService.isTokenExpired(this.token)) {
      this.adminService.logout();
      console.log("Token expired");
    }
  }
  onSubmit() {

    if(!this.costumerLogin.valid &&this.costumerLogin.value.cardNumber == null&& this.costumerLogin.value.mobileNumber == null){

      this.errorDesc = 'Please enter your details to proceed'
      this._toaster.error(this.errorDesc)
    }
    // else if ( parseInt( this.costumerLogin.value.cardHolderNumber) > 4){
    //   this.errorDesc ='Card holder number should be less than 5'
    //   this._toaster.error(this.errorDesc);
    // }
   else if (!this.costumerLogin.valid) {

      this.errorDesc = 'Please enter your card number to proceed.'
      this._toaster.error(this.errorDesc)

    }
    else if (this.costumerLogin.value.cardNumber == null && this.costumerLogin.value.mobileNumber == null) {

      this.errorDesc = 'Please enter your cardNumber number or Mobile Number to proceed.'
      this._toaster.error(this.errorDesc)
    }
    else if (this.costumerLogin.valid && (this.costumerLogin.value.cardNumber != null && this.costumerLogin.value.mobileNumber != null)) {

      this.errorDesc = 'Please enter any one from  cardNumber or Mobile Number.'
      this._toaster.error(this.errorDesc)
    }
    else if (this.costumerLogin.valid && !(this.costumerLogin.value.cardNumber == null || this.costumerLogin.value.mobileNumber == null)) {

      this.errorDesc = 'Please enter your cardholder number with cardNumber number or Mobile Number to proceed  .'
      this._toaster.error(this.errorDesc)
    }


    else {
      this.customerLoginService.customerLogin(this.costumerLogin.value).subscribe((data: any) => {
        if (data.status == 200) {

          console.log(data);
          sessionStorage.clear();
          sessionStorage.setItem('token', data.body.response.accessToken);
          sessionStorage.setItem('id',data.body.response.id)
          sessionStorage.setItem('customerHolderNumber',data.body.response.customerData.customerHolderNumber)
          this._router.navigateByUrl('customerDashboard')
        }

      }, (error) => {
        console.log('false')
        this.error = true;
        this.errorDesc2 = 'Something went Wrong! This could be because of one of three reasons mentioned below: This facility is available only for selected card holders. OR METRO card number entered is incorrect. OR customer mobile entered is incorrect. Kindly call the customer care number 1860-266-2010 (9am to 9pm) for any queries.'


      })
    }
    console.log(this.costumerLogin.value)

  }

}
