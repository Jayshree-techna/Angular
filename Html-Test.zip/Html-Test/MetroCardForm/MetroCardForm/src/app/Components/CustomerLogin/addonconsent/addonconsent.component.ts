import { ToastrService } from 'ngx-toastr';
import { Component } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { CustomerLoginService } from 'src/app/services/customer-login.service';
import { CustomerUploadService } from 'src/app/services/customer-upload.service';
import { AdminLoginService } from 'src/app/services/admin-login.service';
import { AuthServiceService } from 'src/app/services/auth-service.service';
import { SpinnerService } from 'src/app/services/spinner.service';

@Component({
  selector: 'app-addonconsent',
  templateUrl: './addonconsent.component.html',
  styleUrls: ['./addonconsent.component.css']
})
export class AddonconsentComponent {
totalForm =1;
 uniqueId="";
 consentList: consentListing[] = [];
 token="";

constructor(private customerService:CustomerUploadService,private router:ActivatedRoute,
  private toastr:ToastrService,private adminService:AdminLoginService, private authService:AuthServiceService,
  private loader:SpinnerService,private routerService:Router){
}

ngOnInit() {
  this.router.params.subscribe(params => {
     this.uniqueId = params['id'];
    console.log('Unique ID:', this.uniqueId);
    this.getAddonConsent(this.uniqueId);
  });
}

downloadPhoto(filename:string){
  this.adminService.downloadPhoto(filename).subscribe(
    (response: Blob) => {
      const blob = new Blob([response], { type: 'application/octet-stream' });
      console.log('blob--->' + blob);
      const link = document.createElement('a');
      link.href = window.URL.createObjectURL(blob);
      link.download = filename;
      document.body.appendChild(link);

      link.click();

      document.body.removeChild(link);
      this.loader.requestEnded();
      this.toastr.success('Download complete', 'Success');
    },
    (error) => {
      this.loader.requestEnded();
      console.log('2');
      this.toastr.error('Unable to download', 'Error');
    }
  );
}

getAddonConsent(uniqueId:string){
  this.customerService.getConsent(uniqueId).subscribe(
    (data:any)=>{
      if (data && data.response && Array.isArray(data.response)) {
        console.log("consent data---->"+data)
        this.consentList = data.response;
        this.totalForm= this.consentList.length;
        console.log("total form ---->"+this.totalForm)
      } else {
        console.error('Invalid API response format:', data);
      }
      console.log(this.consentList);
    },
    (error) => {
      console.error('Error fetching data', error);
      this.toastr.error('Error fetching data', 'Error');
    }
  )
}

saveConsent() {
  this.customerService.submitConsent(this.uniqueId).subscribe(
    (data:any)=>{
      this.toastr.success('Consent saved successfully', 'Success');
      this.routerService.navigate(['/thankYou']);
    },
    (error) => {
      console.error('Error saving consent', error);
      this.toastr.error('Error saving consent', 'Error');
    }
  );
}
 isToggled=false;
  toggle(){
    this.isToggled=!this.isToggled;
  }

}
export interface consentListing {
  consentId: string;
  applicantName: string;
  applicantMobile: string;
  applicantEmail: string;
  applicantFileName: string;
  applicantGender: string;
  positionDesc: string;
  cardNo: string;
  consent: number;
  addonNo:number;
}
