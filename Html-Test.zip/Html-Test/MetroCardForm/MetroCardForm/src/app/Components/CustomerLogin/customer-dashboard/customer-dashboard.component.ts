import { Component } from '@angular/core';
import { Router } from '@angular/router';
import { ToastrService } from 'ngx-toastr';
import { EmailUpdate } from 'src/app/model/EmailUpdate';
import { AdminLoginService } from 'src/app/services/admin-login.service';
import { AuthServiceService } from 'src/app/services/auth-service.service';
import { CustomerUploadService } from 'src/app/services/customer-upload.service';
import { DataService } from 'src/app/services/data.service';
import { OtpService } from 'src/app/services/otp.service';
import { SpinnerService } from 'src/app/services/spinner.service';

@Component({
  selector: 'app-customer-dashboard',
  templateUrl: './customer-dashboard.component.html',
  styleUrls: ['./customer-dashboard.component.css'],
})
export class CustomerDashboardComponent {
  title = 'Please Select Your Option';
  emailUpdate = false;
  otp = 0;
  email: EmailUpdate = new EmailUpdate();
  customerId: any = '';
  otpBox = false;
  emailError = false;
token="";
  isChecked = false;
  isOtpValidated=false;
  isOtpGenerated=false;
  isAddon=false
  customerHolderNumber: string | null | undefined;

  constructor(
    private router: Router,
    private customerService: CustomerUploadService,
    private toaster: ToastrService,
    private otpService: OtpService,
    private dataService: DataService,
    private loader: SpinnerService,
    private adminService:AdminLoginService,
    private authService:AuthServiceService
  ) {
    this.customerId = sessionStorage.getItem('id');
    this.getCustomerDashboardData(this.customerId);
  }
  ngOnit() {
    this.token =sessionStorage.getItem('token')??'';
    if (this.authService.isTokenExpired(this.token)) {
      this.adminService.logout();
      console.log("Token expired");
    }
  }

  addonCount = 0;
  referCount = 0;

  id = 0;

  getCustomerDashboardData(customerId: any) {
    console.log('Dashboard loaded');
    this.loader.requestStarted();
    this.customerService

      .getCustomerDashboardData(customerId)
      .subscribe((data: any) => {
        if (data != null) {
          this.loader.requestEnded();
          console.log(data);
          this.email.cardNo = data.body.response.cardNumber;
          this.email.companyName = data.body.response.companyName;
          this.email.mobile = data.body.response.mobile;
          this.email.email = data.body.response.email;
          this.email.id = data.body.response.id;
          this.id = data.body.response.id;
          this.email.eligibleAddOn = data.body.response.eligibleAddOn;
          this.email.eligibleReferral = data.body.response.eligibleReferral;
          this.addonCount = data.body.response.eligibleAddOn;
          this.referCount = data.body.response.eligibleReferral;


          sessionStorage.setItem('cardNumber', data.body.response.cardNumber);
          sessionStorage.setItem('mobile', data.body.response.mobile);
          sessionStorage.setItem('companyName', data.body.response.companyName);
          sessionStorage.setItem('email', data.body.response.email);
          sessionStorage.setItem('addonCount', data.body.response.eligibleAddOn);
          sessionStorage.setItem('referCount', data.body.response.eligibleReferral);
          sessionStorage.setItem('custId', data.body.response.id);


          this.customerHolderNumber = sessionStorage.getItem('customerHolderNumber')

          console.log(this.customerHolderNumber)
console.log("type of "+typeof(this.customerHolderNumber))

          if(this.customerHolderNumber === "1"){
            console.log("into the customernumber")
          this.isAddon = !this.isAddon
        }

          this.dataService.setEmailValue(this.email);
          console.log(
            'addon--->' + this.addonCount + 'ref--->' + this.referCount
          );
        }
      });
  }
  showEmailUpdate() {
   console.log("into show email update");
   console.log(this.customerHolderNumber)
   console.log("type of "+typeof(this.customerHolderNumber))
    this.emailUpdate = !this.emailUpdate;



  }


  generateEmailOtp() {
    if (this.email.newEmail == null) {
      this.toaster.error('Enter valid email');
    }
    this.otpBox = !this.otpBox;
    if (this.otpBox) {
      console.log(this.id);
      this.otpService.generateEmailOtp(this.id, this.email.newEmail).subscribe(
        (data: any) => {
          this.toaster.success(data.message, 'Success');
        },
        (error) => {
          this.toaster.error(error.error.message, 'Error');
        }
      );
    }
  }

  newEmailUpdateOtpValidate() {
    if (
      this.email.otp === null ||
      this.email.otp === undefined ||
      this.email.otp.trim() === ''
    ) {
      this.toaster.error('Enter otp');
    }

    if (this.email.otp) {
      console.log('email update-' + this.email.cardNo);
      console.log('email update-' + this.email.newEmail);
      console.log('email update-' + this.email.otp);
      console.log('email update-' + this.email.otpType);

      if (this.customerId !== null) {
        this.email.customerId = this.customerId;
      }

      this.otpService.validateMailOtp(this.email.id, this.email.otp).subscribe(
        (data: any) => {
          this.toaster.success(data.message, 'Success');
          if (data.status === 200) {
            this.loader.requestStarted();
            this.customerService.emailUpdate(this.email).subscribe(
              (res: any) => {
                this.loader.requestEnded();
                this.toaster.success("Email updated successfully", 'Success');
                this.emailUpdate = !this.emailUpdate;
                this.isChecked = false;
                this.email.newEmail = '';
                this.email.otp = '';
                this.otpBox = false;
                this.emailUpdate=false;
              },
              (error) => {
                this.loader.requestEnded();
                this.toaster.error(error.error.message, 'Error');
                this.emailUpdate = !this.emailUpdate;
                this.isChecked = true;
                // this.email.newEmail = '';
                // this.email.otp = '';
                this.otpBox = true;
                this.emailUpdate=true;
              }
            );
          }
        },
        (error) => {
          this.loader.requestEnded();
          this.toaster.error(error.error.message, 'Error');
          this.emailUpdate = !this.emailUpdate;
          this.isChecked = true;
          // this.email.newEmail = '';
          // this.email.otp = '';
          this.otpBox = true;
          this.emailUpdate=true;
        }
      );
    }
  }

  addOnForm() {
    this.router.navigate(['/addOnForm']);
  }
  referForm() {
    this.router.navigate(['/referFriend']);
  }
}
