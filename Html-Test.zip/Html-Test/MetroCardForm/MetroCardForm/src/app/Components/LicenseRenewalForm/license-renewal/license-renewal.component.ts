import { Component } from '@angular/core';
import {
  FormBuilder,
  FormControl,
  FormGroup,
  Validators,
} from '@angular/forms';
import { Router } from '@angular/router';
import { ToastrService } from 'ngx-toastr';
import { AuthServiceService } from 'src/app/services/auth-service.service';
import {
  CustomerLogin,
  CustomerLoginService,
} from 'src/app/services/customer-login.service';
import { OtpService } from 'src/app/services/otp.service';
import {
  Businessclassification,
  CommunicationMedium,
  LicenceRenewalService,
  LicenseCustomerData,
  LicenseList,
} from '../../../services/licence-renewal.service';

@Component({
  selector: 'app-license-renewal',
  templateUrl: './license-renewal.component.html',
  styleUrls: ['./license-renewal.component.css'],
})
export class LicenseRenewalComponent {
  title = 'Please Update Your Data';
  licenseToken: string = '';
  licenseMsg = '';
  classification: any = 'select';

  IssameMobileNumberInMetro: boolean = true;
  isSameMobileNoWhatsapp: boolean = false;
  isMainOtpGenerated: boolean = false;
  isMainOtpValidated: boolean = false;
  isOtpGenerated: boolean = false;
  notusingWatsapp: boolean = false;
  isMailOtpValid: boolean = false;
  noError: boolean = false;
  noMainError: boolean = false;

  licenseForm: FormGroup = new FormGroup({});
  licenseList: LicenseList[] = [];
  businessclassification: Businessclassification[] = [];
  socialmedia: CommunicationMedium[] = [];
  chatbot: CommunicationMedium[] = [];
  advertisement: CommunicationMedium[] = [];

  licenseFile: any = '';
  kycFile: any = '';
  businessUnitFile: any = '';
  addressProofFile: any = '';

  segmentValue: Businessclassification = {
    id: 0,
    businessSegment: '',
    businessClassification: '',
  };

  customerData: LicenseCustomerData = {
    mobile: '',
    cardNumber: '',
    id: 0,
    licenseExpireOn: '',
    companyName: '',
  };

  constructor(
    private license: LicenceRenewalService,
    private fb: FormBuilder,
    private toster: ToastrService,
    private otpService: OtpService,
    private customerService: CustomerLoginService,
    private router: Router,
    private authService: AuthServiceService
  ) {}

  ngOnInit(): void {
    this.licenseForm = this.fb.group({
      customerId: [0],
      applicantMobile: ['', [Validators.required, Validators.minLength(10)]],
      cardNumber: ['', [Validators.required, Validators.minLength(10)]],
      companyName: [{ value: '', disabled: true }, [Validators.required]],
      licenseTypeId: [null, Validators.required],
      applicantWhatsapp: [
        {
          value: '',
          disabled: this.licenseForm.get('notUsingWhatsapp')?.value,
        },
      ],
      isSameMobileNumber: [false],
      notUsingWhatsapp: [false],
      applicantEmail: [
        '',
        [
          Validators.required,
          Validators.email,
          Validators.pattern(
            '^[\\w-\\+]+(\\.[\\w]+)*@[\\w-]+(\\.[\\w]+)*(\\.[a-z]{2,})$'
          ),
        ],
      ],
      applicantNewMobile: [''],
      businessSegment: [null,[Validators.required]],
      businessClassificationId: [null,[Validators.required]],
      otherBusinessClassification: ['',[Validators.required]],
      currentBusinessAddress: [''],
      socialMediaId: [null,[Validators.required]],
      chatMediaId: [null,[Validators.required]],
      adMediaId: [null,[Validators.required]],
      modeCorrection: [null,[Validators.required]],
      srid: [''],
    });

    this.licenseForm
      .get('isSameMobileNumber')
      ?.valueChanges.subscribe((value) => {
        if (value) {
          this.licenseForm.patchValue({
            applicantWhatsapp: this.licenseForm.value.applicantMobile,
          });
        } else {
          this.licenseForm.patchValue({
            applicantWhatsapp: '',
          });
        }
      });
  }

  get applicantEmail(): FormControl {
    return this.licenseForm.get('applicantEmail') as FormControl;
  }

  get CardNumber(): FormControl {
    return this.licenseForm.get('cardNumber') as FormControl;
  }

  get ApplicantMobile(): FormControl {
    return this.licenseForm.get('applicantMobile') as FormControl;
  }

  get LicenseType():FormControl{
    return this.licenseForm.get('licenseTypeId') as FormControl;
  }

  get BusinessClassification():FormControl{
    return this.licenseForm.get('businessClassificationId') as FormControl;
  }

  get OtherClassification():FormControl{
    return this.licenseForm.get('otherBusinessClassification') as FormControl;
  }

  get SocialMedia(): FormControl{
    return this.licenseForm.get('socialMediaId') as FormControl;
  }

  get ChatBox(): FormControl{
    return this.licenseForm.get('chatMediaId') as FormControl;
  }

  get Advertisement(): FormControl{
    return this.licenseForm.get('adMediaId') as FormControl;
  }

  get Mode():FormControl{
    return this.licenseForm.get('modeCorrection') as FormControl;
  }

  spaceAtFirst(event: any) {
    if (event.target.selectionStart === 0 && event.code === 'Space') {
      event.preventDefault();
    }
  }

  zeroAtFirst(event: any) {
    if (event.target.selectionStart == 0 && event.code === 'Digit0') {
      event.preventDefault();
    }
  }

  getCustomerData() {
    if (
      this.licenseForm.value.applicantMobile.toString().length == 0 &&
      this.licenseForm.value.cardNumber.toString().length == 0
    ) {
      this.toster.error('Please enter 10 digit Mobile No. or Card No.');
    } else if (
      this.licenseForm.value.applicantMobile.toString().length != 0 &&
      this.licenseForm.value.applicantMobile.toString().length < 10
    ) {
      this.toster.error('Please enter 10 digit mobile No.');
    } else if (
      this.licenseForm.value.cardNumber.toString().length != 0 &&
      this.licenseForm.value.cardNumber.toString().length < 10
    ) {
      this.toster.error('Please enter 10 digit card No.');
    } else {
      const customerDto: CustomerLogin = {
        mobileNumber: this.licenseForm.value.applicantMobile,
        cardNumber: this.licenseForm.value.cardNumber,
        cardHolderNumber: '',
      };
      this.customerService.customerLogin(customerDto).subscribe(
        (data: any) => {
          this.licenseToken = data.body.response.accessToken;
          // this.license.saveLicenseFormToken(this.licenseToken);
          this.customerData = data.body.response.customerData;

          //Calling License dropdown list
          this.getLicenseList();
          this.licenseForm.patchValue({
            customerId: this.customerData.id,
            cardNumber: this.customerData.cardNumber,
            applicantMobile: this.customerData.mobile,
          });
          const now = new Date();
          const licenseExpirydate = new Date(this.customerData.licenseExpireOn);
          const monthsDifference: number =
            (licenseExpirydate.getFullYear() - now.getFullYear()) * 12 +
            (licenseExpirydate.getMonth() - now.getMonth());
          if (licenseExpirydate < now) {
            this.licenseMsg = 'License is expired';
          }
          if (monthsDifference <= 2) {
            this.licenseMsg = 'License is about to expire in next 2 months';
          }
        },
        (error) => {
          if (error.status == 0) {
            this.toster.error('Unable to connect to server');
          } else if (error.status == 500) {
            this.toster.error('Internal Server Error');
          } else this.toster.error(error.error.message);
        }
      );
    }
  }

  getLicenseList() {
    this.license
      .getLicenseDropDownData(this.licenseToken)
      .subscribe((data: any) => {
        this.licenseList = data.response.licenseType;
        this.businessclassification = data.response.businessClassificationDto;
        this.socialmedia = data.response.socialMedia;
        this.chatbot = data.response.chatbot;
        this.advertisement = data.response.advertisement;
      });
  }

  getLicenseFile(event: any) {
    this.licenseFile = event.target.files[0];
    // let fileExtension:string=this.licenseFile.name.replace(" ","_");
    // console.log("license_copy.   --> "+fileExtension);
    const fileSize = this.licenseFile.size;
    const fileMb = fileSize / 1024 ** 2;
    if (fileMb > 10) {
      event.target.value = null;
      this.toster.error('please select a file below 10 MB.');
    }
  }

  getKycFile(event: any) {
    this.kycFile = event.target.files[0];
    const fileSize = this.kycFile.size;
    const fileMb = fileSize / 1024 ** 2;
    if (fileMb > 10) {
      event.target.value = null;
      this.toster.error('please select a file below 10 MB.');
    }
  }

  getBusinessProofFile(event: any) {
    this.addressProofFile = event.target.files[0];
    const fileSize = this.addressProofFile.size;
    const fileMb = fileSize / 1024 ** 2;
    if (fileMb > 10) {
      event.target.value = null;
      this.toster.error('please select a file below 10 MB.');
    }
  }

  getBusinessUnitFile(event: any) {
    this.businessUnitFile = event.target.files[0];
  }

  generateOtp() {
    this.isOtpGenerated = !this.isOtpGenerated;
    this.noError = false;
    if (this.CardNumber.errors?.['required'] && this.isOtpGenerated) {
      this.toster.error('Please enter Card No.');
    } else if (this.CardNumber.errors?.['minlength'] && this.isOtpGenerated) {
      this.toster.error('Enter 10 digit Card No.');
    } else if (
      this.applicantEmail.errors?.['required'] &&
      this.isOtpGenerated
    ) {
      this.toster.error('Please enter Email Address.');
    } else if (this.applicantEmail.errors?.['pattern'] && this.isOtpGenerated) {
      this.toster.error('Please enter valid Email Address.');
    } else if (this.customerData.id == 0 && this.isOtpGenerated) {
      this.toster.error('Please validate your data.');
    } else {
      this.noError = true;
      if (this.isOtpGenerated) {
        let customerId = this.customerData.id;
        let custEmail = this.licenseForm.get('applicantEmail')?.value;
        this.otpService.generateEmailOtp(customerId, custEmail).subscribe(
          (result: any) => {
            if (result.status == 200 || result.status == '200') {
              this.toster.success(result.message);
            }
          },
          (error) => {
            if (error.status == 0) {
              this.toster.error('Unable to connect to server');
            } else if (error.status == 500) {
              this.toster.error('Internal Server Error');
            } else this.toster.error(error.error.message);
          }
        );
      }
    }
  }

  validateOtp(otp: string) {
    if (otp.length == 0) {
      this.toster.error('Please enter valid OTP.');
    } else {
      let customerId = this.customerData.id;
      this.otpService.validateMailOtp(customerId, otp).subscribe(
        (result: any) => {
          if (result.status == 200 || result.status == '200') {
            this.isMailOtpValid = true;
          }
        },
        (err) => {
          if (err.status == 0) {
            this.toster.error('Unable to connect to server');
          } else if (err.status == 500) {
            this.toster.error('Internal Server Error');
          }
          this.toster.error(err.error.message);
        }
      );
    }
  }

  getSegment(event: any) {
    const segmentValue1 = this.businessclassification.filter(
      (business) => business.id == event.target.value
    );
    this.licenseForm.patchValue({
      businessSegment: segmentValue1[0]?.businessSegment,
    });
    this.classification = segmentValue1[0]?.businessClassification;
  }

  onSubmit() {
    let licenseDto: FormData = new FormData();
    licenseDto.append('licenseDto', JSON.stringify(this.licenseForm.value));
    // let fileExtension:string=this.licenseFile.name.split('?')[0].split('.').pop();
    licenseDto.append(
      'file1',
      this.licenseFile,
      this.licenseFile.name.replace(' ', '_')
    );
    licenseDto.append(
      'file2',
      this.kycFile,
      this.kycFile.name.replace(' ', '_')
    );
    licenseDto.append(
      'file3',
      this.addressProofFile,
      this.addressProofFile.name.replace(' ', '_')
    );
    licenseDto.append(
      'file4',
      this.businessUnitFile,
      this.businessUnitFile.name.replace(' ', '_')
    );
    this.license.submitLicenseForm(licenseDto, this.licenseToken).subscribe(
      (data: any) => {
        if (data.status == 200) {
          this.router.navigateByUrl('/thankYou');
        }
      },
      (err) => {
        this.router.navigateByUrl('/error');
      }
    );
  }

  generateMainOtp() {
    this.isMainOtpGenerated = !this.isMainOtpGenerated;
    this.noMainError = false;
    if (this.CardNumber.errors?.['required'] && this.isMainOtpGenerated) {
      this.toster.error('Please enter Card No.');
    } else if (
      this.CardNumber.errors?.['minlength'] &&
      this.isMainOtpGenerated
    ) {
      this.toster.error('Please enter 10 digit card No.');
    } else if (
      this.ApplicantMobile.errors?.['required'] &&
      this.isMainOtpGenerated
    ) {
      this.toster.error('Please enter Mobile No.');
    } else if (
      this.ApplicantMobile.errors?.['minlength'] &&
      this.isMainOtpGenerated
    ) {
      this.toster.error('Please enter 10 digit mobile No.');
    } else if (
      this.licenseForm.value.applicantWhatsapp.toString().length < 10 &&
      !this.licenseForm.controls['notUsingWhatsapp'].value &&
      this.isMainOtpGenerated
    ) {
      this.toster.error('Please enter 10 digit Whatsapp No.');
    } else if (
      this.LicenseType.errors?.['required'] &&
      this.isMainOtpGenerated
    ) {
      this.toster.error('Please select your business license type.');
    } else if (this.licenseFile == '' && this.isMainOtpGenerated) {
      this.toster.error('Please upload your License File.');
    } else if (!this.kycFile && this.isMainOtpGenerated) {
      this.toster.error('Please upload your Kyc File.');
    } else if (
      !this.IssameMobileNumberInMetro &&
      this.licenseForm.value.applicantNewMobile.toString().length < 10 &&
      this.isMainOtpGenerated
    ) {
      this.toster.error('Please enter your 10 digit new Mobile No.');
    } else if (
      this.BusinessClassification.errors?.['required'] &&
      this.isMainOtpGenerated
    ) {
      this.toster.error('Please select your business classification.');
    } else if (this.classification === 'Others' && this.licenseForm.value.otherBusinessClassification=='' && this.isMainOtpGenerated) {
      this.toster.error('Please enter other business.');
    } else if (
      this.licenseForm.value.currentBusinessAddress != '' &&
      !this.addressProofFile &&
      this.isMainOtpGenerated
    ) {
      this.toster.error('Please upload your Business proof.');
    } else if (
      this.SocialMedia.errors?.['required'] &&
      this.isMainOtpGenerated
    ) {
      this.toster.error('Please select social media.');
    } else if (
      this.ChatBox.errors?.['required'] &&
      this.isMainOtpGenerated
    ) {
      this.toster.error('Please select chatbot.');
    } else if (
      this.Advertisement.errors?.['required'] &&
      this.isMainOtpGenerated
    ) {
      this.toster.error('Please select advertisement.');
    } else if (!this.businessUnitFile && this.isMainOtpGenerated) {
      this.toster.error('Please upload Business Unit File.');
    } else if (
      this.Mode.errors?.['required'] &&
      this.isMainOtpGenerated
    ) {
      this.toster.error('Please select Mode.');
    } else if (
      this.licenseForm.controls['modeCorrection'].value == 'CRM Manpower' &&
      this.licenseForm.value.srid == '' &&
      this.isMainOtpGenerated
    ) {
      this.toster.error('Please enter your srid.');
    } else {
      if (this.isMainOtpGenerated) {
        this.noMainError = true;
        let customerId: number = this.customerData.id;
        this.otpService
          .generateMainOtp(
            customerId,
            this.licenseForm.get('applicantMobile')?.value
          )
          .subscribe(
            (res) => {
              if (res.status == 200 || res.status == '200') {
                this.noError = true;
                this.toster.success('OTP sent successfully.');
              }
            },
            (err) => {
              this.toster.error('Failed to send Otp.');
            }
          );
      }
    }
  }

  validateMainOtp(mainOtp: string) {
    if (mainOtp.length == 0) {
      this.toster.error('Please enter valid OTP.');
    } else {
      this.otpService
        .validateMainMailOtp(this.licenseForm.value.customerId, mainOtp)
        .subscribe(
          (result: any) => {
            if (result.status == 200 || result.status == '200') {
              this.isMainOtpValidated = true;
              // this.noMainError=false;
            }
          },
          (err) => {
            this.toster.error(err.error.message);
          }
        );
    }
  }
}
