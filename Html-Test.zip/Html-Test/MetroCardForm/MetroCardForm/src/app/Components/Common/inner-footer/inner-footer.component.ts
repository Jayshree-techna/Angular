import { Component, Input } from '@angular/core';

@Component({
  selector: 'app-inner-footer',
  templateUrl: './inner-footer.component.html',
  styleUrls: ['./inner-footer.component.css']
})
export class InnerFooterComponent {
@Input() value:boolean | undefined;
// @Input() disable:boolean|undefined;
}
