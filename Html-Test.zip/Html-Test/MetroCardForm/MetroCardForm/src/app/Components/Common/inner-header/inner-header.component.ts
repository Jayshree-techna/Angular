import { Component, Input } from '@angular/core';

@Component({
  selector: 'app-inner-header',
  templateUrl: './inner-header.component.html',
  styleUrls: ['./inner-header.component.css']
})
export class InnerHeaderComponent {
  @Input() title: string | undefined ;
  @Input() title2:string | undefined;

  ngOnInit(){
    console.log("title----->"+this.title);
  }
}
