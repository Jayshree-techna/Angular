export class EmailUpdate {
  customerId = '';
  id = 0;
  cardNo = '';
  mobile: any;
  companyName = '';
  eligibleAddOn = 0;
  eligibleReferral=0
  email = '';
  newEmail = '';
  otp = '';
  otpType = 'newemail-otp';
  next: any;
}
