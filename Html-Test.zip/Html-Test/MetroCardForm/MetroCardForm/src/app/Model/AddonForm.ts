export interface AddonForm {
  addonApplicantName: string;
  addonApplicantMobile: string;
  addonApplicantEmail: string;
  addonApplicantGender: string;
  addonPositionId: number;
  [key: string]: any; // Index signature to allow any string keys
}


export class AddonSubmit {
  customerId: number = 0;
  addonForm: AddonForm[] = [];
}
