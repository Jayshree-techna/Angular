package com.micro.productservice.util;

import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.GetMapping;
 
@FeignClient("department-service")
public interface FeignServiceUtil {
	@GetMapping("user/name")
	String getName();
	@GetMapping("user/address")
	String getAddress();
	@GetMapping("user/status")
	String getStatus();
 
}