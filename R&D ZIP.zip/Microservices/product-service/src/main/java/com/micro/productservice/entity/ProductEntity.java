// @Data
// @NoArgsConstructor
// @AllArgsConstructor
// @Entity
// @Table(name = "mst_product")
// public class ProductEntity {

// 	@Id
// 	@GeneratedValue(strategy = GenerationType.IDENTITY)
// 	@Column(name = "product_id")
// 	private String productId;

// 	@Column(name = "product_name", nullable = false)
// 	private String productName;

// 	// @Column(name = "department_descrption", nullable = false)
// 	// private String departmentDescrption;

// 	@Column(name = "created_by", nullable = true)
// 	private String createdBy;

// 	@Column(name = "created_by_name", nullable = true)
// 	private String createdByName = null;

// 	@CreationTimestamp
// 	@Column(name = "created_on", nullable = false, updatable = false)
// 	private Timestamp createdOn;

// 	@Column(name = "updated_by", nullable = true)
// 	private String updatedBy;

// 	@Column(name = "updated_by_name", nullable = true)
// 	private String updatedByName;

// 	@UpdateTimestamp
// 	@Column(name = "updated_on", nullable = false)
// 	private Timestamp updatedOn;

// 	@Column(name = "is_active", nullable = false)
// 	private Boolean isActive;

// 	@Column(name = "is_deleted", nullable = false)
// 	private Boolean isDeleted;

// }