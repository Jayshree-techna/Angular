package micro.departmentservice.controller;

import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import micro.departmentservice.model.Department;
import micro.departmentservice.repository.DepartmentRepository;

@RestController
@RequestMapping("/department")
public class DepartmentController {

	private static final Logger Logger = LoggerFactory.getLogger(DepartmentController.class);

	@Autowired
	private DepartmentRepository repository;

	@PostMapping("/add")
	public List<Department> add(@RequestBody Department department) {
		Logger.info("Department add:{}",department);
		return repository.addDepartment(department);
	}
	
	@GetMapping ("/get")
	public List<Department> findAll(){
		Logger.info("Department find");
		return repository.findAll()
;	}

	@GetMapping("/{id}")
	public Department findById(@PathVariable Long id) {
		Logger.info("Department find by id={}", id);
		return repository.findById(id);
	}
	
}
