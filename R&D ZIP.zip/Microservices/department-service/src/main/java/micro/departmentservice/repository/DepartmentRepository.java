package micro.departmentservice.repository;

import java.util.ArrayList;
import java.util.List;

import org.springframework.stereotype.Repository;

import micro.departmentservice.model.Department;

@Repository
public class DepartmentRepository {

	private List<Department> departments = new ArrayList<>();
	
	public List<Department> addDepartment(Department dept) {
		departments.add(dept);
		return departments;
	}
	
	public Department findById(Long id) {
		return departments.stream().
				filter(department->department.getId().equals(id))
				.findFirst()
				.orElseThrow();
	}
	
	public List<Department> findAll(){
		return departments;
	}
	
	
}
