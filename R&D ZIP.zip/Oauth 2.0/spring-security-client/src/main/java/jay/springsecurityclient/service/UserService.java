package jay.springsecurityclient.service;

import java.util.Optional;

import jay.springsecurityclient.entity.User;
import jay.springsecurityclient.entity.VerificationToken;
import jay.springsecurityclient.model.UserModel;

public interface UserService {
	User registerUser(UserModel userModel);


	String validateVerificationToken(String token);

	VerificationToken generateNewVerificationToken(String oldToken);

	User findUserByEmail(String email);

	void createPasswordResetTokenForUser(User user, String token);

	String validatePasswordResetToken(String token);

	Optional<User> getUserByPasswordResetToken(String token);

	void changePassword(User user, String newPassword);

	boolean checkIfValidOldPassword(User user, String oldPassword);

	void saveVerificationTokenForUser(String token, User user);
}
