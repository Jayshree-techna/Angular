package jay.rxjava.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import jay.rxjava.entity.User;
import jay.rxjava.service.UserService;

@RestController
@RequestMapping("/user")
public class UserController {
	@Autowired
	UserService userService;

	@GetMapping("/get-customer")
	public List<User> getCustomer() {
		return userService.getAllUsers();
	}

	@GetMapping("/getByCustomerName")
	public List<User> getByCustomerName(@RequestParam("name") String name) {
		return userService.getByCustomerName(name);
	}

	@DeleteMapping("/{id}")
	public Object deleteUser(@PathVariable String id) {
		return userService.deleteUser(id);
	}

	@GetMapping("/age")
	public List<User> getByAge(@RequestParam Integer minAge, @RequestParam Integer maxAge) {
		return userService.getByAge(minAge, maxAge);
	}

}
