package jay.rxjava.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import jay.rxjava.entity.User;
import jay.rxjava.repository.UserRepository;

@Service
public class UserService {
	@Autowired
	private UserRepository userRepository;

	public List<User> getAllUsers() {
		return userRepository.findAll();
	}

	public List<User> getByCustomerName(String name) {
		return userRepository.findByNameStartsWith(name);
	}

	public Object deleteUser(String id) {
		 userRepository.deleteById(id);
		 return "Deleted successfully";
	}

	public List<User> getByAge(Integer minAge,Integer maxAge) {
		return userRepository.findByAgeBetween(minAge,maxAge);
	}
}