package jay.rxjava.controller;

import java.util.Observable;

public class test {
	public static void main(String[] args) {
//		Observable<String> observable = Observable.just("hello", "world");
//
//		observable.subscribe(item -> System.out.println("Recieved :" + item),
//				error -> System.out.println("Error :" + error), () -> System.out.println("Completed"));
	}
}
