package jay.rxjava.repository;

import java.util.List;

import org.springframework.data.mongodb.repository.MongoRepository;
import org.springframework.data.mongodb.repository.Query;

import jay.rxjava.entity.User;

public interface UserRepository extends MongoRepository<User, String> {

	List<User> findByNameStartsWith(String name);

	// List<User> findByAgeBetween(Integer minAge, Integer maxAge);

	@Query(value = "{age:{$gt:?0,$lt:?1}}",fields="{name:1}")
	List<User> findByAgeBetween(Integer min, Integer max);
	
	
}
