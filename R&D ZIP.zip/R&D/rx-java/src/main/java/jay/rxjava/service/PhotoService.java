package jay.rxjava.service;

import org.springframework.web.multipart.MultipartFile;

import jay.rxjava.collection.Photo;

public interface PhotoService {

	String save(String fileName,MultipartFile image);

	Photo getPhoto(String id);

}
