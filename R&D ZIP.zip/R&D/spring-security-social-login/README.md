# Spring Security Social Login

Instructions 

https://docs.github.com/en/apps/oauth-apps/building-oauth-apps/authorizing-oauth-apps 

new app -> https://github.com/settings/applications/new


## Google Login 

http://localhost:8080/login/oauth2/code/google

https://github.com/TwiN/spring-security-oauth2-client-example